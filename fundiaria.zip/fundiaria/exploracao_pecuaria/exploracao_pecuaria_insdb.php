<?php
	session_start();
	if(!isset($_SESSION['access'])){
		print "Acesso direto negado!";
		exit;
	}
	include_once('../includes/connection.inc.php');
	include_once('../includes/functions.inc.php');

	$codigo_pecuaria = $_POST[codigo_pecuaria];
$codigo_irrigante_pecuaria = $_POST[codigo_irrigante_pecuaria];

$bovino_pecuaria = $_POST[bovino_pecuaria];
$caprino_pecuaria = $_POST[caprino_pecuaria];
$ave_pecuaria = $_POST[ave_pecuaria];
$ovino_pecuaria = $_POST[ovino_pecuaria];
$nenhuma_pecuaria = $_POST[nenhuma_pecuaria];
$outra__pecuaria = $_POST[outra__pecuaria];
$carcinicultura_pecuaria = $_POST[carcinicultura_pecuaria];
$psicultura_pecuaria = $_POST[psicultura_pecuaria];
$suinocultura_pecuaria = $_POST[suinocultura_pecuaria];
$apicultura_pecuaria = $_POST[apicultura_pecuaria];

if(isset($_POST[bovino_pecuaria]))
{
	$bovino_pecuaria = $_POST[bovino_pecuaria];
}
else
{
	$bovino_pecuaria  = 'N';
}
if(isset($_POST[caprino_pecuaria]))
{
	$caprino_pecuaria = $_POST[caprino_pecuaria];
}
else
{
	$caprino_pecuaria  = 'N';
}
if(isset($_POST[ave_pecuaria]))
{
	$ave_pecuaria = $_POST[ave_pecuaria];
}
else
{
	$ave_pecuaria  = 'N';
}
if(isset($_POST[ovino_pecuaria]))
{
	$ovino_pecuaria = $_POST[ovino_pecuaria];
}
else
{
	$ovino_pecuaria  = 'N';
}
if(isset($_POST[nenhuma_pecuaria]))
{
	$nenhuma_pecuaria = $_POST[nenhuma_pecuaria];
}
else
{
	$nenhuma_pecuaria  = 'N';
}
if(isset($_POST[carcinicultura_pecuaria]))
{
	$carcinicultura_pecuaria = $_POST[carcinicultura_pecuaria];
}
else
{
	$carcinicultura_pecuaria  = 'N';
}
if(isset($_POST[psicultura_pecuaria]))
{
	$psicultura_pecuaria = $_POST[psicultura_pecuaria];
}
else
{
	$psicultura_pecuaria  = 'N';
}
if(isset($_POST[suinocultura_pecuaria]))
{
	$suinocultura_pecuaria = $_POST[suinocultura_pecuaria];
}
else
{
	$suinocultura_pecuaria  = 'N';
}
if(isset($_POST[apicultura_pecuaria]))
{
	$apicultura_pecuaria = $_POST[apicultura_pecuaria];
}
else
{
	$apicultura_pecuaria  = 'N';
}

if(isset($_POST[outra__pecuaria]))
{
	$outra__pecuaria = $_POST[outra__pecuaria];
}
else
{
	$outra__pecuaria  = 'N';
}

$bovino_pecuaria_quantidade = $_POST[bovino_pecuaria_quantidade];
$caprino_pecuaria_quantidade = $_POST[caprino_pecuaria_quantidade];
$ave_pecuaria_quantidade = $_POST[ave_pecuaria_quantidade];
$ovino_pecuaria_quantidade = $_POST[ovino_pecuaria_quantidade];
$outra__pecuaria_quantidade = $_POST[outra__pecuaria_quantidade];
$carcinicultura_pecuaria_quantidade = $_POST[carcinicultura_pecuaria_quantidade];
$psicultura_pecuaria_quantidade = $_POST[psicultura_pecuaria_quantidade];
$suinocultura_pecuaria_quantidade = $_POST[suinocultura_pecuaria_quantidade];
$apicultura_pecuaria_quantidade = $_POST[apicultura_pecuaria_quantidade];

$table = 'exploracao_pecuaria';

$strInsert = "INSERT INTO $table (codigo_pecuaria,codigo_irrigante_pecuaria,bovino_pecuaria,caprino_pecuaria,ave_pecuaria,ovino_pecuaria,nenhuma_pecuaria,outra__pecuaria,carcinicultura_pecuaria,
psicultura_pecuaria,suinocultura_pecuaria,bovino_pecuaria_quantidade,caprino_pecuaria_quantidade,ave_pecuaria_quantidade,ovino_pecuaria_quantidade,
carcinicultura_pecuaria_quantidade,psicultura_pecuaria_quantidade,suinocultura_pecuaria_quantidade,apicultura_pecuaria_quantidade,outra__pecuaria_quantidade,apicultura_pecuaria) 
	VALUES ('$codigo_pecuaria','$codigo_irrigante_pecuaria','$bovino_pecuaria','$caprino_pecuaria','$ave_pecuaria','$ovino_pecuaria','$nenhuma_pecuaria','$outra__pecuaria','$carcinicultura_pecuaria',
	'$psicultura_pecuaria','$suinocultura_pecuaria','$bovino_pecuaria_quantidade','$caprino_pecuaria_quantidade','$ave_pecuaria_quantidade','$ovino_pecuaria_quantidade',
	'$carcinicultura_pecuaria_quantidade','$psicultura_pecuaria_quantidade','$suinocultura_pecuaria_quantidade','$apicultura_pecuaria_quantidade','$outra__pecuaria_quantidade','$apicultura_pecuaria')";

	if($sgbd=='my'){
		$insert = mysql_query($strInsert);
	}elseif($sgbd=='pg'){
		$insert = pg_query($strInsert);
	}

	if (!$insert){
		if($sgbd=='my'){
			echo mysql_error()."Erro: Falha ao inserir o registro!";
			exit;
		}elseif($sgbd=='pg'){
			echo pg_last_error()."Erro: Falha ao inserir o registro!";
			exit;
		}
	}

	echo "<script>location='../grid.php?table=exploracao_pecuaria';</script>";
	?>
	