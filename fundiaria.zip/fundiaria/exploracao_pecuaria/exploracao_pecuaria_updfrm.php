<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>

<?php
error_reporting(0);
ini_set(“display_errors”, 0 );
?>
	
	<?php
	session_start();
	//if(!isset($_SESSION['access'])){
	//	print "Acesso direto negado!";
	//	exit;
	//}
	if ($_SESSION['admin'] <> 's')
	{
		echo" <script>alert('Usuário não possui autorização para editar.');</script>";
		echo "<script>location='../menu.php';</script>";			
	}

	include_once('../includes/lang.php'); 
	if($lang=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif($lang=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/connection.inc.php');
	include_once('../includes/header2.php');
	include_once('../includes/functions.inc.php');
	include_once('../includes/includes.html');

		$table = 'exploracao_pecuaria';
		$c=0;
		$count = count(primary_key($table));
		foreach(primary_key($table) as $p){
			if($c < $count-1){
				$pk .= $p . ',';
			}else{
				$pk .= $p;
			}
			$c ++;
		}

		$pk0 = explode(',',$pk);

		if($count ==1){
			$pk1=$pk0[0];
			$value1 = $_GET[$pk1];
			$value = "$pk1 = '$value1'";
		}elseif($count ==2){
			$pk1=$pk0[0];
			$pk2=$pk0[1];

			$value1 = $_GET[$pk1];
			$value2 = $_GET[$pk2];
			$value = "$pk1 = '$value1' AND $pk2 = '$value2'";
		}

		$sql = "SELECT * FROM $table where $value";	
	

		if($sgbd == 'my'){
			$qry = mysql_query($sql);
			$reg = mysql_fetch_array($qry);
		}elseif($sgbd == 'pg'){
			$qry = pg_query($sql);
			$reg = pg_fetch_array($qry);
		}
	if($sgbd == 'my'){
		$nf=mysql_num_fields($qry);
		for($x=0;$x<$nf;$x++){
			$type = mysql_field_type($qry,$x);
			if($type == 'date'){
				$datefield = explode('-',$reg[$x]);
				$reg[$x] = $datefield[2].'/'.$datefield[1].'/'.$datefield[0];
				$dataget = $reg[$x];
			}
		}
	}elseif($sgbd == 'pg'){
		$nf=pg_num_fields($qry);
		for($x=0;$x<$nf;$x++){
			$type = pg_field_type($qry,$x);
			if($type == 'date'){
				$datefield = explode('-',$reg[$x]);
				$reg[$x] = $datefield[2].'/'.$datefield[1].'/'.$datefield[0];
				$dataget = $reg[$x];
			}
		}
	}
	?>
	
	<script src="../includes/validate/jquery.validationEngine_br.js" type="text/javascript"></script>
	
	<body onLoad="document.frmUpdate.codigo_irrigante_pecuaria.focus()">
	<br>
	<h2 align=center><?php echo 'Editar ' .ucfirst(Exploracao). ' ' . 'Pecuaria';?></h2>
	<br>
	<form name="frm_exploracao_pecuaria" method="post" action="exploracao_pecuaria_upddb.php" id="test">
<table border="0" align="center">
		<input type="hidden" name="data2" value="<?php echo $dataget;?>">
		<table border="0" align="center">
		<tr><td>Codigo_pecuaria</td><td><input name="codigo_pecuaria" type="text" size="4" maxlength="4" value="<?php echo trim($reg[0]);?>" readonly style="background-color:AliceBlue" onFocus="status_msg.value='Este campo é obrigatório'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Codigo Irrigante</td><td>
	<select name="codigo_irrigante_pecuaria">
		<?php echo combo_codigo_irrigante_pecuaria("codigo_irrigante", $reg[1], "irrigante");?>
		</select>		
	</td></tr>	
</table>	
	<table border="0" align="center">	
	<tr>
		<td></td><td><b><font size=2><b> EXPLORAÇÃO </b></font></td><td></td>
	</tr>	
	</table>
	<table border="0" align="center">
	<tr>
		<th align='left'><input name="bovino_pecuaria" type="checkbox" value="<?php echo trim($reg[2]);?>"
			<?php if (trim($reg[2])=='S'){
				echo 'checked=true'; }?>> Bovinocultura -->&nbsp
			Quantidade &nbsp <input name="bovino_pecuaria_quantidade" type="text" size="6" maxlength="6" value="<?php echo trim($reg[13]);?>" onBlur="status_msg.value=''"></th>				
		<th align='left'>
			<input name="caprino_pecuaria" type="checkbox" value="<?php echo trim($reg[3]);?>"
			<?php if (trim($reg[3])=='S'){
				echo 'checked=true'; }?>>Caprinocultura -->&nbsp				
			Quantidade &nbsp <input name="caprino_pecuaria_quantidade" type="text" size="6" maxlength="6" value="<?php echo trim($reg[14]);?>" onBlur="status_msg.value=''"></th>				
	</tr>		
	<tr>
		<th align='left'>
			<input name="ave_pecuaria" type="checkbox" value="<?php echo trim($reg[4]);?>"
			<?php if (trim($reg[4])=='S'){
				echo 'checked=true'; }?>> Avicultura -->&nbsp &nbsp &nbsp &nbsp &nbsp
		Quantidade &nbsp <input name="ave_pecuaria_quantidade" type="text" size="6" maxlength="6" value="<?php echo trim($reg[15]);?>" onBlur="status_msg.value=''"></th>						
		<th align='left'>
			<input name="ovino_pecuaria" type="checkbox" value="<?php echo trim($reg[5]);?>"
			<?php if (trim($reg[5])=='S'){
				echo 'checked=true'; }?>>Ovinocultura -->&nbsp &nbsp &nbsp &nbsp &nbsp		
		Quantidade &nbsp &nbsp <input name="ovino_pecuaria_quantidade" type="text" size="6" maxlength="6" value="<?php echo trim($reg[16]);?>" onBlur="status_msg.value=''"></th>		
	</tr>		
	<tr>
		<th align='left'>
			<input name="carcinicultura_pecuaria" type="checkbox" value="<?php echo trim($reg[8]);?>"
			<?php if (trim($reg[8])=='S'){
				echo 'checked=true'; }?>>Carcinicultura -->&nbsp &nbsp
			Quantidade &nbsp <input name="carcinicultura_pecuaria_quantidade" type="text" size="6" maxlength="6" value="<?php echo trim($reg[17]);?>" onBlur="status_msg.value=''"></th>			
		<th align='left'>
		<input name="psicultura_pecuaria" type="checkbox" value="<?php echo trim($reg[9]);?>"
			<?php if (trim($reg[9])=='S'){
				echo 'checked=true'; }?>>Psicultura -->&nbsp &nbsp
			Quantidade &nbsp  <input name="psicultura_pecuaria_quantidade" type="text" size="6" maxlength="6" value="<?php echo trim($reg[18]);?>" onBlur="status_msg.value=''"></th>				
		</th>
	</tr>	
	<tr>
		<th align='left'>
			<input name="suinocultura_pecuaria" type="checkbox" value="<?php echo trim($reg[10]);?>"
			<?php if (trim($reg[10])=='S'){
				echo 'checked=true'; }?>>Suinocultura -->&nbsp &nbsp			
			Quantidade &nbsp  <input name="suinocultura_pecuaria_quantidade" type="text" size="6" maxlength="6" value="<?php echo trim($reg[19]);?>" onBlur="status_msg.value=''"></th>				

			
			<th align='left'>
			<input name="apicultura_pecuaria" type="checkbox" value="<?php echo trim($reg[11]);?>"
			<?php if (trim($reg[11])=='S'){
				echo 'checked=true'; }?>>Apicultura -->&nbsp &nbsp			
			Quantidade &nbsp  <input name="apicultura_pecuaria_quantidade" type="text" size="6" maxlength="6" value="<?php echo trim($reg[12]);?>" onBlur="status_msg.value=''"></th>			
	</tr>
	<tr>
		<th align='left'>
		<input name="nenhuma_pecuaria" type="checkbox" value="<?php echo trim($reg[7]);?>"
			<?php if (trim($reg[7])=='S'){
				echo 'checked=true'; }?>>Nenhuma			
		</th>	
	</tr>	
	</table>	
	<table border="0" align="center">	
	<tr><th>Outra &nbsp <input name="outra__pecuaria" type="text" size="" maxlength="" onFocus="status_msg.value='Campo outra__pecuaria'" onBlur="status_msg.value=''" value="<?php echo trim($reg[6]);?>">
		Quantidade &nbsp  <input name="outra__pecuaria_quantidade" type="text" size="6" maxlength="6" value="<?php echo trim($reg[20]);?>" onBlur="status_msg.value=''"></th>				
	</tr>
	</table>	
	<table border="0" align="center">
	<tr><td></td><td><input type="submit" class="submit" value="Atualizar"></td></tr>
		<tr><td colspan="2"><input type="text" id="status_msg" name="status_msg" value="outra__pecuaria" size="60" readonly></td></tr>
	</table>
	</form>

	<?php 
	include_once("../includes/footer2.php"); 
	?>
	