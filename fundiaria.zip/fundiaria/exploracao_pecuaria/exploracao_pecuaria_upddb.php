<?php
	session_start();
	if(!isset($_SESSION['admin'])){
		print "Acesso direto negado!";
		exit;
	}
	include_once('../includes/connection.inc.php');
	include_once('../includes/functions.inc.php');
	$codigo_pecuaria = $_POST[codigo_pecuaria];
$codigo_irrigante_pecuaria = $_POST[codigo_irrigante_pecuaria];
$bovino_pecuaria = $_POST[bovino_pecuaria];
$caprino_pecuaria = $_POST[caprino_pecuaria];
$ave_pecuaria = $_POST[ave_pecuaria];
$ovino_pecuaria = $_POST[ovino_pecuaria];
$nenhuma_pecuaria = $_POST[nenhuma_pecuaria];
$outra__pecuaria = $_POST[outra__pecuaria];
$carcinicultura_pecuaria = $_POST[carcinicultura_pecuaria];
$psicultura_pecuaria = $_POST[psicultura_pecuaria];
$suinocultura_pecuaria = $_POST[suinocultura_pecuaria];
$apicultura_pecuaria = $_POST[apicultura_pecuaria];

$bovino_pecuaria_quantidade = $_POST[bovino_pecuaria_quantidade];
$caprino_pecuaria_quantidade = $_POST[caprino_pecuaria_quantidade];
$ave_pecuaria_quantidade = $_POST[ave_pecuaria_quantidade];
$ovino_pecuaria_quantidade = $_POST[ovino_pecuaria_quantidade];
$outra__pecuaria_quantidade = $_POST[outra__pecuaria_quantidade];
$carcinicultura_pecuaria_quantidade = $_POST[carcinicultura_pecuaria_quantidade];
$psicultura_pecuaria_quantidade = $_POST[psicultura_pecuaria_quantidade];
$suinocultura_pecuaria_quantidade = $_POST[suinocultura_pecuaria_quantidade];
$apicultura_pecuaria_quantidade = $_POST[apicultura_pecuaria_quantidade];


if(isset($_POST[bovino_pecuaria]))
{
	$bovino_pecuaria = 'S';
}
else
{
	$bovino_pecuaria  = 'N';
}

if(isset($_POST[caprino_pecuaria]))
{
	$caprino_pecuaria = 'S';
}
else
{
	$caprino_pecuaria  = 'N';	
}

if(isset($_POST[ave_pecuaria]))
{
	$ave_pecuaria = 'S';
}
else
{
	$ave_pecuaria  = 'N';
}

if(isset($_POST[ovino_pecuaria]))
{
	$ovino_pecuaria = 'S';
}
else
{
	$ovino_pecuaria  = 'N';
}

if(isset($_POST[nenhuma_pecuaria]))
{
	$nenhuma_pecuaria = 'S';
}
else
{
	$nenhuma_pecuaria  = 'N';
}
if(isset($_POST[carcinicultura_pecuaria]))
{
	$carcinicultura_pecuaria = 'S';
}
else
{
	$carcinicultura_pecuaria  = 'N';
}
if(isset($_POST[psicultura_pecuaria]))
{
	$psicultura_pecuaria = 'S';
}
else
{
	$psicultura_pecuaria  = 'N';
}
if(isset($_POST[suinocultura_pecuaria]))
{
	$suinocultura_pecuaria = 'S';
}
else
{
	$suinocultura_pecuaria  = 'N';
}
if(isset($_POST[apicultura_pecuaria]))
{
	$apicultura_pecuaria = $_POST[apicultura_pecuaria];
}
else
{
	$apicultura_pecuaria  = 'N';
}
if(isset($_POST[outra__pecuaria]))
{
	$outra__pecuaria = $_POST[outra__pecuaria];
}
else
{
	$outra__pecuaria  = 'N';
}

$table = 'exploracao_pecuaria';

	// Support to multiple primary key
		$c=0;
		$count = count(primary_key($table));
		foreach(primary_key($table) as $p){
			if($c < $count-1){
				$pk .= $p . ',';
			}else{
				$pk .= $p;
			}
			$c ++;
		}

		$pk0 = explode(',',$pk);

	if($count ==1){
		$pk1=$pk0[0];
		$value1 = $_POST[$pk1];
		$value = "$pk1 = '$value1'";
	}elseif($count ==2){
		$pk1=$pk0[0];
		$pk2=$pk0[1];

		$value1 = $_POST[$pk1];
		$value2 = $_POST[$pk2];
		$value = "$pk1 = '$value1' AND $pk2 = '$value2'";
	}

	
$strUpdate="UPDATE $table SET codigo_pecuaria = '$codigo_pecuaria', codigo_irrigante_pecuaria = '$codigo_irrigante_pecuaria', bovino_pecuaria = '$bovino_pecuaria', caprino_pecuaria = '$caprino_pecuaria',
ave_pecuaria = '$ave_pecuaria',ovino_pecuaria = '$ovino_pecuaria',nenhuma_pecuaria = '$nenhuma_pecuaria',outra__pecuaria = '$outra__pecuaria',carcinicultura_pecuaria='$carcinicultura_pecuaria',
psicultura_pecuaria='$psicultura_pecuaria',suinocultura_pecuaria='$suinocultura_pecuaria',apicultura_pecuaria='$apicultura_pecuaria',bovino_pecuaria_quantidade ='$bovino_pecuaria_quantidade',
caprino_pecuaria_quantidade='$caprino_pecuaria_quantidade',ave_pecuaria_quantidade='$ave_pecuaria_quantidade',ovino_pecuaria_quantidade='$ovino_pecuaria_quantidade',
outra__pecuaria_quantidade='$outra__pecuaria_quantidade',carcinicultura_pecuaria_quantidade='$carcinicultura_pecuaria_quantidade',psicultura_pecuaria_quantidade='$psicultura_pecuaria_quantidade',
suinocultura_pecuaria_quantidade='$suinocultura_pecuaria_quantidade',apicultura_pecuaria_quantidade='$apicultura_pecuaria_quantidade' WHERE $value ";

	if($sgbd=='my'){
		mysql_query($strUpdate) or die(mysql_error());
	}elseif($sgbd=='pg'){
		pg_query($strUpdate) or die(pg_last_error());
	}
	echo "<script>location='../grid.php?table=$table'</script>";
	?>
	