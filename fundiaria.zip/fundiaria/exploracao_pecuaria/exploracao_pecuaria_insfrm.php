<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
	<?php 	
	//session_start();
	//if(!isset($_SESSION['access'])){
	//	print "Acesso direto negado!";
	//	exit;
	//}
	include_once('../includes/lang.php'); 
	if($lang=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif($lang=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/connection.inc.php');
	include_once('../includes/header2.php');
	include_once('../includes/functions.inc.php');
	include_once('../includes/includes.html');
	
	$strconsulta = pg_exec("SELECT MAX(codigo_pecuaria) AS codigo_pecuaria FROM exploracao_pecuaria");
	$cd_codigo=(pg_result($strconsulta,0,'codigo_pecuaria')+1);
	
	?>
	
	<script>
	function quantidade(area_lote_ha){
		v = area_lote_ha.value;
		v=v.replace(/\D/g,"") //permite digitar apenas números
		//v=v.replace(/[0-9]{12}/,"inválido") //limita pra máximo 999.999.999,99
		//v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") //coloca ponto antes dos últimos 8 digitos
		//v=v.replace(/(\d{1})(\d{1,2})$/,"$1.$2") //coloca ponto antes dos últimos 5 digitos
		v=v.replace(/(\d{1})(\d{3,2})$/,"$1,$2") //coloca virgula antes dos últimos 4 digitos
		area_lote_ha.value = v;
	}
	</script>
	
	
	<script src="../includes/validate/jquery.validationEngine_br.js" type="text/javascript"></script>
	
	<br>
	<body onLoad="document.frmInsert.codigo_irrigante_pecuaria.focus()">
	<h2 align=center><?php echo Adicionar.' '.ucfirst(Exploração) . ' ' . 'Pecuaria';?></h2>
	<br>
	<form method="POST" id="test" action="exploracao_pecuaria_insdb.php" name="frmInsert">
	<table border="0" align="center">
	<tr><td>Código <input name="codigo_pecuaria" type="text" id="codigo_pecuaria" class="validate[required]" size="4" maxlength="4" <?php echo"value='$cd_codigo'";?> onFocus="status_msg.value='Ente campo é obrigatório'"  onBlur="status_msg.value=''" style="background-color:AliceBlue " READONLY></td></tr>
	<tr><td>Codigo Irrigante
	<select name="codigo_irrigante_pecuaria">
		<?php echo combo_codigo_irrigante_pecuaria("codigo_irrigante", 0, "irrigante");?>
		</select>		
	</td></tr>	
	<tr></tr><tr></tr><tr></tr>
	</table>	
	<table border="0" align="center">
	
	<tr>
		<td></td><td><b><font size=2><b> EXPLORAÇÃO </b></font></td><td></td>
	</tr>	
	</table>
	<table border="0" align="center">
	<tr>
		<th><align='left'><input name="bovino_pecuaria" type="checkbox" value="S">Bovinocultura	-->&nbsp		
		Quantidade &nbsp <input name="bovino_pecuaria_quantidade" type="text" size="4" maxlength="3" onFocus="status_msg.value='Campo goiaba_cultura_ha'" onBlur="status_msg.value=''"></th>		
		<th><align='left'>&nbsp &nbsp &nbsp &nbsp &nbsp  <input name="caprino_pecuaria" type="checkbox" value="S">Caprinocultura -->&nbsp
		Quantidade &nbsp <input name="caprino_pecuaria_quantidade" type="text" size="4" maxlength="3" onFocus="status_msg.value='Campo goiaba_cultura_ha'" onBlur="status_msg.value=''"></th>			
	</tr>
	<tr>
		<th align='left'><input name="ave_pecuaria" type="checkbox" value="S">Avicultura -->&nbsp &nbsp &nbsp &nbsp &nbsp
		Quantidade &nbsp <input name="ave_pecuaria_quantidade" type="text" size="4" maxlength="3" onFocus="status_msg.value='Campo goiaba_cultura_ha'" onBlur="status_msg.value=''"></th>		
		<th align='left'>&nbsp &nbsp &nbsp &nbsp &nbsp <input name="ovino_pecuaria" type="checkbox" value="S">Ovinocultura -->&nbsp 
		Quantidade &nbsp &nbsp <input name="ovino_pecuaria_quantidade" type="text" size="4" maxlength="3" onFocus="status_msg.value='Campo goiaba_cultura_ha'" onBlur="status_msg.value=''"></th>			
		
	</tr>
	<tr>
		<th align='left'><input name="carcinicultura_pecuaria" type="checkbox" value="S">Carcinicultura -->&nbsp&nbsp
		Quantidade &nbsp <input name="carcinicultura_pecuaria_quantidade" type="text" size="4" maxlength="3" onFocus="status_msg.value='Campo goiaba_cultura_ha'" onBlur="status_msg.value=''"></th>		
		<th align='left'>&nbsp &nbsp &nbsp &nbsp &nbsp <input name="psicultura_pecuaria" type="checkbox" value="S">Psicultura -->&nbsp &nbsp &nbsp &nbsp &nbsp 
		Quantidade &nbsp  <input name="psicultura_pecuaria_quantidade" type="text" size="4" maxlength="3" onFocus="status_msg.value='Campo goiaba_cultura_ha'" onBlur="status_msg.value=''"></th>				
	</tr>	
	<tr>
		<th align='left'><input name="suinocultura_pecuaria" type="checkbox" value="S">Suinocultura -->&nbsp &nbsp&nbsp
		Quantidade &nbsp  <input name="suinocultura_pecuaria_quantidade" type="text" size="4" maxlength="3" onFocus="status_msg.value='Campo goiaba_cultura_ha'" onBlur="status_msg.value=''"></th>				
		<th align='left'>&nbsp &nbsp &nbsp &nbsp &nbsp <input name="apicultura_pecuaria" type="checkbox" value="S">Apicultura -->&nbsp &nbsp &nbsp &nbsp &nbsp
		Quantidade &nbsp  <input name="apicultura_pecuaria_quantidade" type="text" size="4" maxlength="3" onFocus="status_msg.value='Campo goiaba_cultura_ha'" onBlur="status_msg.value=''"></th>				
	</tr>	
	<tr>
		<th align='left'>
			<input name="nenhuma_pecuaria" type="checkbox" value="S">Nenhuma
		</th>	
	</tr>		
	</table>
	<table border="0" align="center">
	<tr>	
		<th>Outra <input name="outra__pecuaria" type="text" size="20" maxlength="20" onFocus="status_msg.value='Campo outra__pecuaria'" onBlur="status_msg.value=''"> &nbsp &nbsp
		Quantidade &nbsp  <input name="outra__pecuaria_quantidade" type="text" size="4" maxlength="3" onFocus="status_msg.value='Campo goiaba_cultura_ha'" onBlur="status_msg.value=''"></th>				
	</tr>
	</table>	
	<table border="0" align="center">	
	<tr></tr><tr></tr>
	<tr></tr><tr></tr>
	<tr><td></td><td>&nbsp &nbsp &nbsp &nbsp <input type="submit" class="submit" value="Inserir"></td></tr>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
		<tr><td colspan="2"><input type="text" id="status_msg" name="status_msg" value="outra__pecuaria" size="60" readonly></td></tr>
	</table>

	</form>

	<?php 
	include_once("../includes/footer2.php"); 
	?>
	