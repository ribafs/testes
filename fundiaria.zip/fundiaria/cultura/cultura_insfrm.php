<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
	<?php 	
	//session_start();
	//if(!isset($_SESSION['access'])){
	//	print "Acesso direto negado!";
	//	exit;
	//}
	include_once('../includes/lang.php'); 
	if($lang=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif($lang=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/connection.inc.php');
	include_once('../includes/header2.php');
	include_once('../includes/functions.inc.php');
	include_once('../includes/includes.html');
	
	$strconsulta = pg_exec("SELECT MAX(codigo_cultura) AS codigo FROM cultura");
	$cd_codigo=(pg_result($strconsulta,0,'codigo')+1);
	?>
	<script type="text/javascript" src="../includes/mascara_moeda.js"></script>
	<script src="../includes/validate/jquery.validationEngine_br.js" type="text/javascript"></script>
	
	<script>
	function hectare(area_lote_ha){
		v = area_lote_ha.value;
		v=v.replace(/\D/g,"") //permite digitar apenas números
		//v=v.replace(/[0-9]{12}/,"inválido") //limita pra máximo 999.999.999,99
		//v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") //coloca ponto antes dos últimos 8 digitos
		//v=v.replace(/(\d{1})(\d{1,2})$/,"$1.$2") //coloca ponto antes dos últimos 5 digitos
		v=v.replace(/(\d{1})(\d{2,2})$/,"$1,$2") //coloca virgula antes dos últimos 4 digitos
		area_lote_ha.value = v;
	}
	</script>
		
	<br>
	<body onLoad="document.frmInsert.codigo_irrigante_cultura.focus()">
	<h2 align=center><?php echo Adicionar.' '.ucfirst(cultura);?></h2>
	<br>
	<form method="POST" id="test" action="cultura_insdb.php" name="frmInsert">
	<table border="0" align="center">
	<tr><td>Codigo_cultura &nbsp &nbsp <input name="codigo_cultura" type="text" id="codigo_cultura" class="validate[required]" size="4" maxlength="4" <?php echo"value='$cd_codigo'";?> onFocus="status_msg.value='Ente campo é obrigatório'"  onBlur="status_msg.value=''" style="background-color:AliceBlue " READONLY></td></tr>
	<tr><td>Codigo Irrigante &nbsp &nbsp
	<select name="codigo_irrigante_cultura">
		<?php echo combo_codigo_irrigante_cultura("codigo_irrigante", 0, "irrigante");?>
		</select>		
	</td></tr>
	<tr></tr><tr></tr><tr></tr>
	<tr></tr><tr></tr><tr></tr>
	<tr>
		<th colspan=2><font size=2><b> CULTURAS </b></font></th>
	</tr>	
	<tr></tr><tr></tr><tr></tr>
	<tr>
		<th align='left'>
			<input name="banana_cultura" type="checkbox" value="S">Banana
			&nbsp&nbsp	
			ha &nbsp <input name="banana_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onBlur="status_msg.value=''">		
			 &nbsp &nbsp &nbsp &nbsp <input name="sorgo_cultura" type="checkbox" value="S">Sorgo
			&nbsp &nbsp &nbsp &nbsp
			ha &nbsp <input name="sorgo_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo sorgo_cultura_ha'" onBlur="status_msg.value=''">
		</th>				
	</tr>
	<tr>
		<th align='left'>
			<input name="goiaba_cultura" type="checkbox" value="S">Goiaba
			&nbsp &nbsp	
			ha &nbsp <input name="goiaba_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo goiaba_cultura_ha'" onBlur="status_msg.value=''">
		
			 &nbsp &nbsp &nbsp &nbsp <input name="melancia_cultura" type="checkbox" value="S">Melancia
			&nbsp&nbsp
			ha &nbsp <input name="melancia_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo melancia_cultura'" onBlur="status_msg.value=''">
		</th>				
	</tr>
	<tr>
		<th align='left'>
			<input name="milho_cultura" type="checkbox" value="S">Milho
			&nbsp &nbsp	&nbsp
			ha &nbsp <input name="milho_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo milho_cultura_ha'" onBlur="status_msg.value=''">
		
			 &nbsp &nbsp &nbsp &nbsp <input name="abacaxi_cultura" type="checkbox" value="S">Abacaxi
			&nbsp &nbsp &nbsp
			ha &nbsp <input name="abacaxi_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo abacaxi_cultura_ha'" onBlur="status_msg.value=''">
		</th>				
	</tr>
	<tr>
		<th align='left'>
			<input name="arroz_cultura" type="checkbox" value="S">Arroz
			&nbsp &nbsp	&nbsp
			ha &nbsp <input name="arroz_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo arroz_cultura_ha'" onBlur="status_msg.value=''">
		
			 &nbsp &nbsp &nbsp &nbsp <input name="mamao_cultura" type="checkbox" value="S">Mamão
			&nbsp &nbsp &nbsp&nbsp
			ha &nbsp <input name="mamao_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo mamao_cultura_ha'" onBlur="status_msg.value=''">
		</th>				
	</tr>
	<tr>
		<th align='left'>
			<input name="capim_cultura" type="checkbox" value="S">Capim
			&nbsp &nbsp&nbsp
			ha &nbsp <input name="capim_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo capim_cultura_ha'" onBlur="status_msg.value=''">
		
			 &nbsp &nbsp &nbsp &nbsp <input name="coco_cultura" type="checkbox" value="S">Coco
			&nbsp &nbsp &nbsp &nbsp &nbsp 
			ha &nbsp <input name="coco_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo coco_cultura_ha'" onBlur="status_msg.value=''">
		</th>				
	</tr>	
	<tr>
		<th align='left'>
			<input name="feijao_cultura" type="checkbox" value="S">Feijão
			&nbsp &nbsp &nbsp
			ha &nbsp <input name="feijao_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo capim_cultura_ha'" onBlur="status_msg.value=''">
		
			&nbsp &nbsp &nbsp &nbsp <input name="acerola_cultura" type="checkbox" value="S">Acerola
			&nbsp &nbsp &nbsp 
			ha &nbsp <input name="acerola_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo acerola_cultura_ha'" onBlur="status_msg.value=''">
		</th>				
	</tr>		
	<tr>
		<th align='left'>
			<input name="caju_cultura" type="checkbox" value="S">Caju
			&nbsp &nbsp &nbsp &nbsp 
			ha &nbsp <input name="caju_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo caju_cultura_ha'" onBlur="status_msg.value=''">
		
			&nbsp &nbsp &nbsp &nbsp <input name="mandioca_cultura" type="checkbox" value="S">Mandioca
			&nbsp&nbsp
			ha &nbsp <input name="mandioca_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo mandioca_cultura_ha'" onBlur="status_msg.value=''">
		</th>				
	</tr>		
	<tr>
		<th align='left'>
			<input name="uva_cultura" type="checkbox" value="S">Uva
			&nbsp &nbsp &nbsp &nbsp &nbsp
			ha &nbsp <input name="uva_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo uva_cultura_ha'" onBlur="status_msg.value=''">
		
			&nbsp &nbsp &nbsp &nbsp <input name="ata_cultura" type="checkbox" value="S">Ata
			&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
			ha &nbsp <input name="ata_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo ata_cultura_ha'" onBlur="status_msg.value=''">
		</th>				
	</tr>	
	<tr>
		<th align='left'>
			<input name="manga_cultura" type="checkbox" value="S">Manga
			&nbsp&nbsp&nbsp
			ha &nbsp <input name="manga_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo manga_cultura_ha'" onBlur="status_msg.value=''">
		
			&nbsp &nbsp &nbsp &nbsp <input name="macaxeira_cultura" type="checkbox" value="S">Macaxeira
			&nbsp&nbsp
			ha &nbsp <input name="macaxeira_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo macaxeira_cultura_ha'" onBlur="status_msg.value=''">
		</th>				
	</tr>		
	<tr>
		<th align='left'>
			<input name="horta_cultura" type="checkbox" value="S">Horta
			&nbsp &nbsp &nbsp
			ha &nbsp <input name="horta_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo manga_cultura_ha'" onBlur="status_msg.value=''">
		
		</th>				
	</tr>		
	<tr></tr><tr></tr><tr></tr>
	<tr></tr><tr></tr><tr></tr>	
	<tr><th align='left'>Cultura Consorciada: <input name="cultura_consorciada" type="text" size="20" maxlength="20" onFocus="status_msg.value='Campo outra_cultura'" onBlur="status_msg.value=''">	  
	  &nbsp ha <input name="cultura_consorciada_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo outra_cultura_ha'" onBlur="status_msg.value=''">
	<tr></tr><tr></tr>
	<tr><th align='left'>Outra Cultura <input name="outra_cultura" type="text" size="20" maxlength="20" onFocus="status_msg.value='Campo outra_cultura'" onBlur="status_msg.value=''">	  
	  &nbsp ha <input name="outra_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" onFocus="status_msg.value='Campo outra_cultura_ha'" onBlur="status_msg.value=''">
	</th></tr>
	<tr></tr><tr></tr><tr></tr>
	<tr></tr><tr></tr><tr></tr>
	<tr></tr><tr></tr><tr></tr>
	<tr><td align='center'><input type="submit" class="submit" value="Inserir"></td></tr>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
		<tr><td colspan="2"><input type="text" id="status_msg" name="status_msg" value="outra_cultura_ha" size="60" readonly></td></tr>
	</table>
	</form>
	<?php 
	include_once("../includes/footer2.php"); 
	?>
	