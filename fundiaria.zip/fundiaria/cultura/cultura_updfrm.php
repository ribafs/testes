<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
<?php
error_reporting(0);
ini_set(“display_errors”, 0 );
?>

<?php
session_start();
//if(!isset($_SESSION['access'])){
//	print "Acesso direto negado!";
//	exit;
//}
if ($_SESSION['admin'] <> 's')
{
	echo" <script>alert('Usuário não possui autorização para editar.');</script>";
	echo "<script>location='../menu.php';</script>";			
}

	include_once('../includes/lang.php'); 
	if($lang=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif($lang=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/connection.inc.php');
	include_once('../includes/header2.php');
	include_once('../includes/functions.inc.php');
	include_once('../includes/includes.html');

		$table = 'cultura';
		$c=0;
		$count = count(primary_key($table));
		foreach(primary_key($table) as $p){
			if($c < $count-1){
				$pk .= $p . ',';
			}else{
				$pk .= $p;
			}
			$c ++;
		}

		$pk0 = explode(',',$pk);

		if($count ==1){
			$pk1=$pk0[0];
			$value1 = $_GET[$pk1];
			$value = "$pk1 = '$value1'";
		}elseif($count ==2){
			$pk1=$pk0[0];
			$pk2=$pk0[1];

			$value1 = $_GET[$pk1];
			$value2 = $_GET[$pk2];
			$value = "$pk1 = '$value1' AND $pk2 = '$value2'";
		}

		$sql = "SELECT * FROM $table where $value";	
	

		if($sgbd == 'my'){
			$qry = mysql_query($sql);
			$reg = mysql_fetch_array($qry);
		}elseif($sgbd == 'pg'){
			$qry = pg_query($sql);
			$reg = pg_fetch_array($qry);
		}
	if($sgbd == 'my'){
		$nf=mysql_num_fields($qry);
		for($x=0;$x<$nf;$x++){
			$type = mysql_field_type($qry,$x);
			if($type == 'date'){
				$datefield = explode('-',$reg[$x]);
				$reg[$x] = $datefield[2].'/'.$datefield[1].'/'.$datefield[0];
				$dataget = $reg[$x];
			}
		}
	}elseif($sgbd == 'pg'){
		$nf=pg_num_fields($qry);
		for($x=0;$x<$nf;$x++){
			$type = pg_field_type($qry,$x);
			if($type == 'date'){
				$datefield = explode('-',$reg[$x]);
				$reg[$x] = $datefield[2].'/'.$datefield[1].'/'.$datefield[0];
				$dataget = $reg[$x];
			}
		}
	}
	?>
	
	<script src="../includes/validate/jquery.validationEngine_br.js" type="text/javascript"></script>
	
	<script>
	function hectare(area_lote_ha){
		v = area_lote_ha.value;
		v=v.replace(/\D/g,"") //permite digitar apenas números
		//v=v.replace(/[0-9]{12}/,"inválido") //limita pra máximo 999.999.999,99
		//v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") //coloca ponto antes dos últimos 8 digitos
		//v=v.replace(/(\d{1})(\d{1,2})$/,"$1.$2") //coloca ponto antes dos últimos 5 digitos
		v=v.replace(/(\d{1})(\d{2,2})$/,"$1,$2") //coloca virgula antes dos últimos 4 digitos
		area_lote_ha.value = v;
	}
	</script>
	
	<br>
	<body onLoad="document.frmUpdate.codigo_cultura.focus()">
	<h2 align=center><?php echo 'Editar ' .ucfirst(cultura);?></h2>
	<br>
	<form name="frm_cultura" method="post" action="cultura_upddb.php" id="test">
	<table border="0" align="center">
		<input type="hidden" name="data2" value="<?php echo $dataget;?>">
		<table border="0" align="center">
	<tr><td>Codigo_cultura &nbsp &nbsp <input name="codigo_cultura" type="text" id="codigo_cultura" class="validate[required]" size="4" maxlength="4" value="<?php echo trim($reg[0]);?>" readonly style="color:black" onFocus="status_msg.value='Este campo é obrigatório'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Codigo Irrigante &nbsp &nbsp
	<select name="codigo_irrigante_cultura">
		<?php echo combo_codigo_irrigante_cultura("codigo_irrigante", $reg[1], "irrigante");?>
		</select>		
	</td></tr>
	<tr></tr><tr></tr><tr></tr>
	<tr></tr><tr></tr><tr></tr>
	<tr>
		<th colspan=2><font size=2><b> CULTURAS </b></font></th>
	</tr>	
	<tr></tr><tr></tr><tr></tr>	
	<tr>
		<th align='left'>
			<input name="banana_cultura" type="checkbox" value="<?php echo trim($reg[2]);?>"
			<?php if (trim($reg[2])=='S'){
				echo 'checked=true'; }?>> Banana					
			&nbsp&nbsp	
			ha &nbsp <input name="banana_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[3]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
			
			&nbsp &nbsp &nbsp &nbsp <input name="sorgo_cultura" type="checkbox" value="<?php echo trim($reg[4]);?>"
			<?php if (trim($reg[4])=='S'){
				echo 'checked=true'; }?>> Sorgo
			&nbsp &nbsp &nbsp &nbsp
			ha &nbsp <input name="sorgo_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[5]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
		</th>				
	</tr>
	<!---------------------------------------------         -->
	<tr>
		<th align='left'>
			<input name="goiaba_cultura" type="checkbox" value="<?php echo trim($reg[6]);?>"
			<?php if (trim($reg[6])=='S'){
				echo 'checked=true'; }?>> Goiaba					
			&nbsp&nbsp	
			ha &nbsp <input name="goiaba_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[7]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
			
			&nbsp &nbsp &nbsp &nbsp <input name="melancia_cultura" type="checkbox" value="<?php echo trim($reg[8]);?>"
			<?php if (trim($reg[8])=='S'){
				echo 'checked=true'; }?>> Melancia
			&nbsp&nbsp&nbsp
			ha &nbsp <input name="melancia_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[9]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
		</th>				
	</tr>
	<!---------------------------------------------         -->
	<tr>
		<th align='left'>
			<input name="milho_cultura" type="checkbox" value="<?php echo trim($reg[10]);?>"
			<?php if (trim($reg[10])=='S'){
				echo 'checked=true'; }?>> Milho					
			&nbsp &nbsp	&nbsp
			ha &nbsp <input name="milho_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[11]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
			
			&nbsp &nbsp &nbsp &nbsp <input name="abacaxi_cultura" type="checkbox" value="<?php echo trim($reg[12]);?>"
			<?php if (trim($reg[12])=='S'){
				echo 'checked=true'; }?>> Abacaxi
			&nbsp &nbsp&nbsp
			ha &nbsp <input name="abacaxi_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[13]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
		</th>				
	</tr>
	<!---------------------------------------------         -->
	<tr>
		<th align='left'>
			<input name="arroz_cultura" type="checkbox" value="<?php echo trim($reg[14]);?>"
			<?php if (trim($reg[14])=='S'){
				echo 'checked=true'; }?>> Arroz				
			&nbsp &nbsp	&nbsp
			ha &nbsp <input name="arroz_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[15]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
			
			&nbsp &nbsp &nbsp &nbsp <input name="mamao_cultura" type="checkbox" value="<?php echo trim($reg[16]);?>"
			<?php if (trim($reg[16])=='S'){
				echo 'checked=true'; }?>> Mamão
			&nbsp &nbsp&nbsp
			ha &nbsp <input name="mamao_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[17]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
		</th>				
	</tr>
	<!---------------------------------------------         -->
	<tr>
		<th align='left'>
			<input name="capim_cultura" type="checkbox" value="<?php echo trim($reg[18]);?>"
			<?php if (trim($reg[18])=='S'){
				echo 'checked=true'; }?>> Capim
			&nbsp&nbsp&nbsp
			ha &nbsp <input name="capim_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[19]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
			
			&nbsp &nbsp &nbsp &nbsp <input name="coco_cultura" type="checkbox" value="<?php echo trim($reg[20]);?>"
			<?php if (trim($reg[20])=='S'){
				echo 'checked=true'; }?>> Coco
			&nbsp &nbsp &nbsp &nbsp &nbsp
			ha &nbsp <input name="coco_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[21]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
		</th>				
	</tr>
	<!---------------------------------------------         -->
	<tr>
		<th align='left'>
		<input name="feijao_cultura" type="checkbox" value="<?php echo trim($reg[26]);?>"
			<?php if (trim($reg[26])=='S'){
				echo 'checked=true'; }?>> Feijão
			&nbsp&nbsp &nbsp
			ha &nbsp <input name="feijao_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[27]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
				
			&nbsp &nbsp &nbsp &nbsp <input name="acerola_cultura" type="checkbox" value="<?php echo trim($reg[28]);?>"
			<?php if (trim($reg[28])=='S'){
				echo 'checked=true'; }?>> Acerola
			&nbsp &nbsp&nbsp&nbsp
			ha &nbsp <input name="acerola_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[29]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">	
			
		</th>				
	</tr>	
	<!---------------------------------------------         -->	
	<tr>
		<th align='left'>
		<input name="caju_cultura" type="checkbox" value="<?php echo trim($reg[30]);?>"
			<?php if (trim($reg[30])=='S'){
				echo 'checked=true'; }?>> Caju
			&nbsp &nbsp &nbsp &nbsp
			ha &nbsp <input name="caju_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[31]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
				
			&nbsp &nbsp &nbsp&nbsp&nbsp <input name="mandioca_cultura" type="checkbox" value="<?php echo trim($reg[32]);?>"
			<?php if (trim($reg[32])=='S'){
				echo 'checked=true'; }?>> Mandioca
			&nbsp&nbsp
			ha&nbsp <input name="mandioca_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[33]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">	
			
		</th>				
	</tr>	
	<!---------------------------------------------         -->	
	<tr>
		<th align='left'>
		<input name="uva_cultura" type="checkbox" value="<?php echo trim($reg[34]);?>"
			<?php if (trim($reg[34])=='S'){
				echo 'checked=true'; }?>> Uva
			&nbsp &nbsp &nbsp &nbsp &nbsp
			ha &nbsp <input name="uva_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[35]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
				
			&nbsp &nbsp &nbsp &nbsp <input name="ata_cultura" type="checkbox" value="<?php echo trim($reg[36]);?>"
			<?php if (trim($reg[36])=='S'){
				echo 'checked=true'; }?>> Ata
			&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
			ha&nbsp <input name="ata_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[37]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">	
			
		</th>				
	</tr>	
	<!---------------------------------------------         -->	
	<tr>
		<th align='left'>
		<input name="manga_cultura" type="checkbox" value="<?php echo trim($reg[40]);?>"
			<?php if (trim($reg[40])=='S'){
				echo 'checked=true'; }?>> Manga
			&nbsp&nbsp&nbsp
			ha &nbsp <input name="manga_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[41]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
				
			&nbsp &nbsp &nbsp &nbsp <input name="macaxeira_cultura" type="checkbox" value="<?php echo trim($reg[38]);?>"
			<?php if (trim($reg[38])=='S'){
				echo 'checked=true'; }?>> Macaxeira
			&nbsp
			ha&nbsp <input name="macaxeira_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[39]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">	
			
		</th>				
	</tr>	
	<!---------------------------------------------         -->
	<tr>
		<th align='left'>
		<input name="horta_cultura" type="checkbox" value="<?php echo trim($reg[42]);?>"
			<?php if (trim($reg[42])=='S'){
				echo 'checked=true'; }?>> Horta
			&nbsp &nbsp &nbsp
			ha &nbsp <input name="horta_cultura_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[43]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">				
			
			
		</th>				
	</tr>	
	<!---------------------------------------------         -->
	
	<tr></tr><tr></tr><tr></tr>
	<tr></tr><tr></tr><tr></tr>	
	<tr><th align='left'>Cultura Consorciada: <input name="cultura_consorciada" type="text" size="20" maxlength="20" value="<?php echo trim($reg[24]);?>" onFocus="status_msg.value='Campo outra_cultura'" onBlur="status_msg.value=''">	  
	  &nbsp ha <input name="cultura_consorciada_ha" type="text" size="12" maxlength="12" value="<?php echo trim($reg[25]);?>" onKeyUp="hectare(this);" onFocus="hectare(this);" onBlur="status_msg.value=''">
	<tr></tr><tr></tr>
	<tr></tr><tr></tr>
	<tr><th align='left'>Outra Cultura <input name="outra_cultura" type="text" size="20" maxlength="20" value="<?php echo trim($reg[22]);?>" onFocus="status_msg.value='Campo outra_cultura'" onBlur="status_msg.value=''">	  
	  &nbsp ha <input name="outra_cultura_ha" type="text" size="12" maxlength="12" onKeyUp="hectare(this);" value="<?php echo trim($reg[23]);?>" onFocus="hectare(this);" onBlur="status_msg.value=''">
	</th></tr>
	<tr></tr><tr></tr><tr></tr>
	<tr></tr><tr></tr><tr></tr>
	<tr></tr><tr></tr><tr></tr>	
	<tr><td></td><td><input type="submit" class="submit" value="Atualizar"></td></tr>
		<tr><td colspan="2"><input type="text" id="status_msg" name="status_msg" value="outra_cultura_ha" size="60" readonly></td></tr>
	</table>
	</form>

	<?php 
	include_once("../includes/footer2.php"); 
	?>
	