<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
<?php
	session_start();
	if(!isset($_SESSION['admin'])){
		print "Acesso direto negado!";
		exit;
	}
	include_once('../includes/connection.inc.php');
	include_once('../includes/functions.inc.php');
	
	$codigo_cultura = $_POST[codigo_cultura];
	$codigo_irrigante_cultura = $_POST[codigo_irrigante_cultura];

//------------
$banana_cultura = $_POST[banana_cultura];
if(isset($_POST[banana_cultura]))
{
	$banana_cultura = 'S';
}
else
{
	$banana_cultura  = 'N';
}
$banana_cultura_ha = $_POST[banana_cultura_ha];
if ($banana_cultura_ha != "")
{
	$banana_cultura_ha = explode(",",$_POST['banana_cultura_ha']);	
	$banana_cultura_inteiro=str_replace('.','',$banana_cultura_ha[0]);
	$banana_cultura_ha=$banana_cultura_inteiro . '.' . $banana_cultura_ha[1];	
	if ($banana_cultura_ha[1] != ".")
	{
		$banana_cultura_ha = $_POST[banana_cultura_ha];
	}	
}
else
{
	$banana_cultura_ha = 0.0000;
}
//------------
$sorgo_cultura = $_POST[sorgo_cultura];
if(isset($_POST[sorgo_cultura]))
{
	$sorgo_cultura = 'S';
}
else
{
	$sorgo_cultura  = 'N';
}
$sorgo_cultura_ha = $_POST[sorgo_cultura_ha];
if ($sorgo_cultura_ha != "")
{
	$sorgo_cultura_ha = explode(",",$_POST['sorgo_cultura_ha']);
	$sorgo_cultura_inteiro=str_replace('.','',$sorgo_cultura_ha[0]);
	$sorgo_cultura_ha=$sorgo_cultura_inteiro . '.' . $sorgo_cultura_ha[1];	
	if ($sorgo_cultura_ha[1] != "." )
	{
		$sorgo_cultura_ha = $_POST[sorgo_cultura_ha];
	}	
}
else
{
	$sorgo_cultura_ha = 0.0000;
}
//------------
$goiaba_cultura = $_POST[goiaba_cultura];
if(isset($_POST[goiaba_cultura]))
{
	$goiaba_cultura = 'S';
}
else
{
	$goiaba_cultura  = 'N';
}
$goiaba_cultura_ha = $_POST[goiaba_cultura_ha];
if ($goiaba_cultura_ha != "")
{
	$goiaba_cultura_ha = explode(",",$_POST['goiaba_cultura_ha']);
	$goiaba_cultura_inteiro=str_replace('.','',$goiaba_cultura_ha[0]);
	$goiaba_cultura_ha=$goiaba_cultura_inteiro . '.' . $goiaba_cultura_ha[1];
	if ($goiaba_cultura_ha[1] != ".")
	{
		$goiaba_cultura_ha = $_POST[goiaba_cultura_ha];
	}	
}
else
{
	$goiaba_cultura_ha = 0.0000;
}
//------------
$melancia_cultura = $_POST[melancia_cultura];
if(isset($_POST[melancia_cultura]))
{
	$melancia_cultura = 'S';
}
else
{
	$melancia_cultura  = 'N';
}
$melancia_cultura_ha = $_POST[melancia_cultura_ha];

if ($melancia_cultura_ha != "")
{
	$melancia_cultura_ha = explode(",",$_POST['melancia_cultura_ha']);
	$melancia_cultura_inteiro=str_replace('.','',$melancia_cultura_ha[0]);
	$melancia_cultura_ha=$melancia_cultura_inteiro . '.' . $melancia_cultura_ha[1];		
	if ($melancia_cultura_ha[1] != ".")
	{
		$melancia_cultura_ha = $_POST[melancia_cultura_ha];
		
	}	
}
else
{
	$melancia_cultura_ha = 0.0000;
}
//------------
$milho_cultura= $_POST[milho_cultura];
if(isset($_POST[milho_cultura]))
{
	$milho_cultura = 'S';
}
else
{
	$milho_cultura  = 'N';
}
$milho_cultura_ha = $_POST[milho_cultura_ha];
if ($milho_cultura_ha != "")
{
	$milho_cultura_ha = explode(",",$_POST['milho_cultura_ha']);
	$milho_cultura_inteiro=str_replace('.','',$milho_cultura_ha[0]);
	$milho_cultura_ha=$milho_cultura_inteiro . '.' . $milho_cultura_ha[1];	
	if ($milho_cultura_ha[1] != ".")
	{
		$milho_cultura_ha = $_POST[milho_cultura_ha];
	}
}
else
{
	$milho_cultura_ha = 0.0000;
}
//------------
$abacaxi_cultura = $_POST[abacaxi_cultura];
if(isset($_POST[abacaxi_cultura]))
{
	$abacaxi_cultura = 'S';
}
else
{
	$abacaxi_cultura  = 'N';
}
$abacaxi_cultura_ha = $_POST[abacaxi_cultura_ha];
if ($abacaxi_cultura_ha != "")
{
	$abacaxi_cultura_ha = explode(",",$_POST['abacaxi_cultura_ha']);
	$abacaxi_cultura_inteiro=str_replace('.','',$abacaxi_cultura_ha[0]);
	$abacaxi_cultura_ha=$abacaxi_cultura_inteiro . '.' . $abacaxi_cultura_ha[1];	
	if ($abacaxi_cultura_ha[1] != ".")
	{
		$abacaxi_cultura_ha = $_POST[abacaxi_cultura_ha];
	}
}
else
{
	$abacaxi_cultura_ha = 0.0000;
}
//------------
$arroz_cultura = $_POST[arroz_cultura];
if(isset($_POST[arroz_cultura]))
{
	$arroz_cultura = 'S';
}
else
{
	$arroz_cultura  = 'N';
}
$arroz_cultura_ha = $_POST[arroz_cultura_ha];
if ($arroz_cultura_ha != "")
{
	$arroz_cultura_ha = explode(",",$_POST['arroz_cultura_ha']);
	$arroz_cultura_inteiro=str_replace('.','',$arroz_cultura_ha[0]);
	$arroz_cultura_ha=$arroz_cultura_inteiro . '.' . $arroz_cultura_ha[1];	
	if ($arroz_cultura_ha[1] != ".")
	{
		$arroz_cultura_ha = $_POST[arroz_cultura_ha];
	}
}
else
{
	$arroz_cultura_ha = 0.0000;
}
//------------
$mamao_cultura = $_POST[mamao_cultura];
if(isset($_POST[mamao_cultura]))
{
	$mamao_cultura = 'S';
}
else
{
	$mamao_cultura  = 'N';
}
$mamao_cultura_ha = $_POST[mamao_cultura_ha];
if ($mamao_cultura_ha != "")
{
	$mamao_cultura_ha = explode(",",$_POST['mamao_cultura_ha']);
	$mamao_cultura_inteiro=str_replace('.','',$mamao_cultura_ha[0]);
	$mamao_cultura_ha=$mamao_cultura_inteiro . '.' . $mamao_cultura_ha[1];	
	if ($mamao_cultura_ha[1] != ".")
	{
		$mamao_cultura_ha = $_POST[mamao_cultura_ha];
	}
}
else
{
	$mamao_cultura_ha = 0.0000;
}
//------------
$capim_cultura = $_POST[capim_cultura];
if(isset($_POST[capim_cultura]))
{
	$capim_cultura = 'S';
}
else
{
	$capim_cultura  = 'N';
}
$capim_cultura_ha = $_POST[capim_cultura_ha];
if ($capim_cultura_ha != "")
{
	$capim_cultura_ha = explode(",",$_POST['capim_cultura_ha']);
	$capim_cultura_inteiro=str_replace('.','',$capim_cultura_ha[0]);
	$capim_cultura_ha=$capim_cultura_inteiro . '.' . $capim_cultura_ha[1];	
	if ($capim_cultura_ha[1] != ".")
	{
		$capim_cultura_ha = $_POST[capim_cultura_ha];
	}
}
else
{
	$capim_cultura_ha = 0.0000;
}
//------------
$coco_cultura = $_POST[coco_cultura];
if(isset($_POST[coco_cultura]))
{
	$coco_cultura = 'S';
}
else
{
	$coco_cultura  = 'N';
}
$coco_cultura_ha = $_POST[coco_cultura_ha];
if ($coco_cultura_ha != "")
{
	$coco_cultura_ha = explode(",",$_POST['coco_cultura_ha']);
	$coco_cultura_inteiro=str_replace('.','',$coco_cultura_ha[0]);
	$coco_cultura_ha=$coco_cultura_inteiro . '.' . $coco_cultura_ha[1];	
	if ($coco_cultura_ha[1] != ".")
	{
		$coco_cultura_ha = $_POST[coco_cultura_ha];
	}
}
else
{
	$coco_cultura_ha = 0.0000;
}
//------------
$feijao_cultura = $_POST[feijao_cultura];
if(isset($_POST[feijao_cultura]))
{
	$feijao_cultura = 'S';
}
else
{
	$feijao_cultura  = 'N';
}
$feijao_cultura_ha = $_POST[feijao_cultura_ha];
if ($feijao_cultura_ha != "")
{
	$feijao_cultura_ha = explode(",",$_POST['feijao_cultura_ha']);
	$feijao_cultura_inteiro=str_replace('.','',$feijao_cultura_ha[0]);
	$feijao_cultura_ha=$feijao_cultura_inteiro . '.' . $feijao_cultura_ha[1];	
	if ($feijao_cultura_ha[1] != ".")
	{
		$feijao_cultura_ha = $_POST[feijao_cultura_ha];
	}
}
else
{
	$feijao_cultura_ha = 0.0000;
}
//------------
$acerola_cultura = $_POST[acerola_cultura];
if(isset($_POST[acerola_cultura]))
{
	$acerola_cultura = 'S';
}
else
{
	$acerola_cultura  = 'N';
}
$acerola_cultura_ha = $_POST[acerola_cultura_ha];
if ($acerola_cultura_ha != "")
{
	$acerola_cultura_ha = explode(",",$_POST['acerola_cultura_ha']);
	$acerola_cultura_inteiro=str_replace('.','',$acerola_cultura_ha[0]);
	$acerola_cultura_ha=$acerola_cultura_inteiro . '.' . $acerola_cultura_ha[1];	
	if ($acerola_cultura_ha[1] != ".")
	{
		$acerola_cultura_ha = $_POST[acerola_cultura_ha];
	}
}
else
{
	$acerola_cultura_ha = 0.00;
}
//------------
$caju_cultura = $_POST[caju_cultura];
if(isset($_POST[caju_cultura]))
{
	$caju_cultura = 'S';
}
else
{
	$caju_cultura  = 'N';
}
$caju_cultura_ha = $_POST[caju_cultura_ha];
if ($caju_cultura_ha != "")
{
	$caju_cultura_ha = explode(",",$_POST['caju_cultura_ha']);
	$caju_cultura_inteiro=str_replace('.','',$caju_cultura_ha[0]);
	$caju_cultura_ha=$caju_cultura_inteiro . '.' . $caju_cultura_ha[1];	
	if ($caju_cultura_ha[1] != ".")
	{
		$caju_cultura_ha = $_POST[caju_cultura_ha];
	}
}
else
{
	$caju_cultura_ha = 0.00;
}
//------------
$mandioca_cultura = $_POST[mandioca_cultura];
if(isset($_POST[mandioca_cultura]))
{
	$mandioca_cultura = 'S';
}
else
{
	$mandioca_cultura  = 'N';
}
$mandioca_cultura_ha = $_POST[mandioca_cultura_ha];
if ($mandioca_cultura_ha != "")
{
	$mandioca_cultura_ha = explode(",",$_POST['mandioca_cultura_ha']);
	$mandioca_cultura_inteiro=str_replace('.','',$mandioca_cultura_ha[0]);
	$mandioca_cultura_ha=$mandioca_cultura_inteiro . '.' . $mandioca_cultura_ha[1];	
	if ($mandioca_cultura_ha[1] != ".")
	{
		$mandioca_cultura_ha = $_POST[mandioca_cultura_ha];
	}
}
else
{
	$mandioca_cultura_ha = 0.00;
}
//------------
$uva_cultura = $_POST[uva_cultura];
if(isset($_POST[uva_cultura]))
{
	$uva_cultura = 'S';
}
else
{
	$uva_cultura  = 'N';
}
$uva_cultura_ha = $_POST[uva_cultura_ha];
if ($uva_cultura_ha != "")
{
	$uva_cultura_ha = explode(",",$_POST['uva_cultura_ha']);
	$uva_cultura_inteiro=str_replace('.','',$uva_cultura_ha[0]);
	$uva_cultura_ha=$uva_cultura_inteiro . '.' . $uva_cultura_ha[1];	
	if ($uva_cultura_ha[1] != ".")
	{
		$uva_cultura_ha = $_POST[uva_cultura_ha];
	}
}
else
{
	$uva_cultura_ha = 0.00;
}
//------------
$ata_cultura = $_POST[ata_cultura];
if(isset($_POST[ata_cultura]))
{
	$ata_cultura = 'S';
}
else
{
	$ata_cultura  = 'N';
}
$ata_cultura_ha = $_POST[ata_cultura_ha];
if ($ata_cultura_ha != "")
{
	$ata_cultura_ha = explode(",",$_POST['ata_cultura_ha']);
	$ata_cultura_inteiro=str_replace('.','',$ata_cultura_ha[0]);
	$ata_cultura_ha=$ata_cultura_inteiro . '.' . $ata_cultura_ha[1];	
	if ($ata_cultura_ha[1] != ".")
	{
		$ata_cultura_ha = $_POST[ata_cultura_ha];
	}
}
else
{
	$ata_cultura_ha = 0.00;
}
//------------
$macaxeira_cultura = $_POST[macaxeira_cultura];
if(isset($_POST[macaxeira_cultura]))
{
	$macaxeira_cultura = 'S';
}
else
{
	$macaxeira_cultura  = 'N';
}
$macaxeira_cultura_ha = $_POST[macaxeira_cultura_ha];
if ($macaxeira_cultura_ha != "")
{
	$macaxeira_cultura_ha = explode(",",$_POST['macaxeira_cultura_ha']);
	$macaxeira_cultura_inteiro=str_replace('.','',$macaxeira_cultura_ha[0]);
	$macaxeira_cultura_ha=$macaxeira_cultura_inteiro . '.' . $macaxeira_cultura_ha[1];	
	if ($macaxeira_cultura_ha[1] != ".")
	{
		$macaxeira_cultura_ha = $_POST[macaxeira_cultura_ha];
	}
}
else
{
	$macaxeira_cultura_ha = 0.00;
}
//------------
$manga_cultura = $_POST[manga_cultura];
if(isset($_POST[manga_cultura]))
{
	$manga_cultura = 'S';
}
else
{
	$manga_cultura  = 'N';
}
$manga_cultura_ha = $_POST[manga_cultura_ha];
if ($manga_cultura_ha != "")
{
	$manga_cultura_ha = explode(",",$_POST['manga_cultura_ha']);
	$manga_cultura_inteiro=str_replace('.','',$manga_cultura_ha[0]);
	$manga_cultura_ha=$manga_cultura_inteiro . '.' . $manga_cultura_ha[1];	
	if ($manga_cultura_ha[1] != ".")
	{
		$manga_cultura_ha = $_POST[manga_cultura_ha];
	}
}
else
{
	$manga_cultura_ha = 0.00;
}
//------------
$horta_cultura = $_POST[horta_cultura];
if(isset($_POST[horta_cultura]))
{
	$horta_cultura = 'S';
}
else
{
	$horta_cultura  = 'N';
}
$horta_cultura_ha = $_POST[horta_cultura_ha];
if ($horta_cultura_ha != "")
{
	$horta_cultura_ha = explode(",",$_POST['horta_cultura_ha']);
	$horta_cultura_inteiro=str_replace('.','',$horta_cultura_ha[0]);
	$horta_cultura_ha=$horta_cultura_inteiro . '.' . $horta_cultura_ha[1];	
	if ($horta_cultura_ha[1] != ".")
	{
		$horta_cultura_ha = $_POST[horta_cultura_ha];
	}
}
else
{
	$horta_cultura_ha = 0.00;
}
//------------
$outra_cultura_ha = $_POST[outra_cultura_ha];
if ($outra_cultura_ha != "")
{
	$outra_cultura_ha = explode(",",$_POST['outra_cultura_ha']);
	$outra_cultura_inteiro=str_replace('.','',$outra_cultura_ha[0]);
	$outra_cultura_ha=$outra_cultura_inteiro . '.' . $outra_cultura_ha[1];		
	if ($outra_cultura_ha[1] != ".")
	{
		$outra_cultura_ha = $_POST[outra_cultura_ha];		
	}
}
else
{
	$outra_cultura_ha == 0.0000;
}
$cultura_consorciada = $_POST[cultura_consorciada];
$cultura_consorciada_ha = $_POST[cultura_consorciada_ha];
if ($cultura_consorciada_ha != "")
{
	$cultura_consorciada_ha = explode(",",$_POST['cultura_consorciada_ha']);
	$cultura_consorciada_inteiro=str_replace('.','',$cultura_consorciada_ha[0]);
	$cultura_consorciada_ha=$cultura_consorciada_inteiro . '.' . $cultura_consorciada_ha[1];	
	if ($cultura_consorciada_ha[1] != ".")
	{
		$cultura_consorciada_ha = $_POST[cultura_consorciada_ha];		
	}
}
else
{
	$cultura_consorciada_ha = 0.0000;
}

$total_area_lote = 0;
$total_cultura = 0;
$sql_area_lote="SELECT codigo_lote, numero_lote,codigo_irrigante_lote,area_lote_ha FROM lote WHERE codigo_irrigante_lote = '$codigo_irrigante_cultura'";
$qr_area_lote = pg_query($sql_area_lote);
$numregs_area_lote = pg_num_rows($qr_area_lote);

if($numregs_area_lote <= 0)
{
	echo"<script>alert('Área do irrigante não cadastrada!')</script>";        
	echo "<script>location='../grid.php?table=cultura';</script>";	
	exit;
}
else{
	while ($i < $numregs_area_lote)     
   	{
		$area_lote_ha = pg_result($qr_area_lote,$i,'area_lote_ha');		
		$total_area_lote = $total_area_lote + $area_lote_ha;
		$i++; 
	}
}

$total_cultura = ($banana_cultura_ha+$sorgo_cultura_ha+$goiaba_cultura_ha+$melancia_cultura_ha+$milho_cultura_ha+$abacaxi_cultura_ha+$arroz_cultura_ha+$mamao_cultura_ha+$capim_cultura_ha+
$coco_cultura_ha+$outra_cultura_ha+$cultura_consorciada_ha+$feijao_cultura_ha+$acerola_cultura_ha+$caju_cultura_ha+$mandioca_cultura_ha+$uva_cultura_ha+$ata_cultura_ha+$macaxeira_cultura_ha+
$manga_cultura_ha+$horta_cultura_ha);

if($total_cultura > $total_area_lote)
{	
	echo "<script>alert('Área das culturas maior que a área total do lote!')</script>";        
	echo "<script>location='../grid.php?table=cultura';</script>";
	exit;
}
$table = 'cultura';

	// Support to multiple primary key
		$c=0;
		$count = count(primary_key($table));
		foreach(primary_key($table) as $p){
			if($c < $count-1){
				$pk .= $p . ',';
			}else{
				$pk .= $p;
			}
			$c ++;
		}

		$pk0 = explode(',',$pk);

	if($count ==1){
		$pk1=$pk0[0];
		$value1 = $_POST[$pk1];
		$value = "$pk1 = '$value1'";
	}elseif($count ==2){
		$pk1=$pk0[0];
		$pk2=$pk0[1];

		$value1 = $_POST[$pk1];
		$value2 = $_POST[$pk2];
		$value = "$pk1 = '$value1' AND $pk2 = '$value2'";
	}
	
$strUpdate="UPDATE $table SET codigo_cultura = '$codigo_cultura', codigo_irrigante_cultura = '$codigo_irrigante_cultura', banana_cultura = '$banana_cultura', banana_cultura_ha = '$banana_cultura_ha', 
sorgo_cultura = '$sorgo_cultura', sorgo_cultura_ha = '$sorgo_cultura_ha', goiaba_cultura = '$goiaba_cultura', goiaba_cultura_ha = '$goiaba_cultura_ha', melancia_cultura = '$melancia_cultura',
melancia_cultura_ha = '$melancia_cultura_ha', milho_cultura = '$milho_cultura', milho_cultura_ha = '$milho_cultura_ha', abacaxi_cultura = '$abacaxi_cultura', abacaxi_cultura_ha = '$abacaxi_cultura_ha',
arroz_cultura = '$arroz_cultura', arroz_cultura_ha = '$arroz_cultura_ha', mamao_cultura = '$mamao_cultura', mamao_cultura_ha = '$mamao_cultura_ha', capim_cultura = '$capim_cultura', capim_cultura_ha = '$capim_cultura_ha',
coco_cultura = '$coco_cultura', coco_cultura_ha = '$coco_cultura_ha', outra_cultura = '$outra_cultura', outra_cultura_ha = '$outra_cultura_ha',cultura_consorciada = '$cultura_consorciada',
cultura_consorciada_ha = '$cultura_consorciada_ha', feijao_cultura = '$feijao_cultura', feijao_cultura_ha = '$feijao_cultura_ha',acerola_cultura='$acerola_cultura',acerola_cultura_ha='$acerola_cultura_ha',
caju_cultura='$caju_cultura',caju_cultura_ha='$caju_cultura_ha',mandioca_cultura='$mandioca_cultura',mandioca_cultura_ha='$mandioca_cultura_ha',uva_cultura='$uva_cultura',uva_cultura_ha='$uva_cultura_ha',ata_cultura='$ata_cultura',
ata_cultura_ha='$ata_cultura_ha',macaxeira_cultura='$macaxeira_cultura',macaxeira_cultura_ha='$macaxeira_cultura_ha',manga_cultura='$manga_cultura',manga_cultura_ha='$manga_cultura_ha',horta_cultura='$horta_cultura',
horta_cultura_ha='$horta_cultura_ha' WHERE $value ";

	if($sgbd=='my'){
		mysql_query($strUpdate) or die(mysql_error());
	}elseif($sgbd=='pg'){
		pg_query($strUpdate) or die(pg_last_error());
	}
	echo "<script>location='../grid.php?table=$table'</script>";
	?>
	