<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
<?php	
	session_start();
	if(!isset($_SESSION['access'])){
		print "Acesso direto negado!";
		exit;
	}
	include_once('../includes/connection.inc.php');
	include_once('../includes/functions.inc.php');

	$codigo_cultura = $_POST[codigo_cultura];
$codigo_irrigante_cultura = $_POST[codigo_irrigante_cultura];

$banana_cultura = $_POST[banana_cultura];
if(isset($_POST[banana_cultura]))
{
	$banana_cultura = $_POST[banana_cultura];
}
else
{
	$banana_cultura  = 'N';
}
$banana_cultura_ha = $_POST[banana_cultura_ha];
if ($banana_cultura_ha != "")
{
	$banana_cultura_ha = explode(",",$_POST['banana_cultura_ha']);
	$banana_cultura_inteiro=str_replace('.','',$banana_cultura_ha[0]);
	$banana_cultura_ha=$banana_cultura_inteiro . '.' . $banana_cultura_ha[1];	
}
else
{
	$banana_cultura_ha = 0.0000;
}
//------------
$sorgo_cultura = $_POST[sorgo_cultura];
if(isset($_POST[sorgo_cultura]))
{
	$sorgo_cultura = $_POST[sorgo_cultura];
}
else
{
	$sorgo_cultura  = 'N';
}
$sorgo_cultura_ha = $_POST[sorgo_cultura_ha];
if ($sorgo_cultura_ha != "")
{
	$sorgo_cultura_ha = explode(",",$_POST['sorgo_cultura_ha']);
	$sorgo_cultura_inteiro=str_replace('.','',$sorgo_cultura_ha[0]);
	$sorgo_cultura_ha=$sorgo_cultura_inteiro . '.' . $sorgo_cultura_ha[1];	
}
else
{
	$sorgo_cultura_ha = 0.0000;
}
//------------
$goiaba_cultura = $_POST[goiaba_cultura];
if(isset($_POST[goiaba_cultura]))
{
	$goiaba_cultura = $_POST[goiaba_cultura];
}
else
{
	$goiaba_cultura  = 'N';
}
$goiaba_cultura_ha = $_POST[goiaba_cultura_ha];
if ($goiaba_cultura_ha != "")
{
	$goiaba_cultura_ha = explode(",",$_POST['goiaba_cultura_ha']);
	$goiaba_cultura_inteiro=str_replace('.','',$goiaba_cultura_ha[0]);
	$goiaba_cultura_ha=$goiaba_cultura_inteiro . '.' . $goiaba_cultura_ha[1];	
}
else
{
	$goiaba_cultura_ha = 0.0000;
}
//------------
$melancia_cultura_ha = $_POST[melancia_cultura_ha];
if(isset($_POST[melancia_cultura]))
{
	$melancia_cultura = $_POST[melancia_cultura];
}
else
{
	$melancia_cultura  = 'N';
}
$melancia_cultura_ha = $_POST[melancia_cultura_ha];
if ($melancia_cultura_ha != "")
{
	$melancia_cultura_ha = explode(",",$_POST['melancia_cultura_ha']);
	$melancia_cultura_inteiro=str_replace('.','',$melancia_cultura_ha[0]);
	$melancia_cultura_ha=$melancia_cultura_inteiro . '.' . $melancia_cultura_ha[1];	
}
else
{
	$melancia_cultura_ha = 0.0000;
}
//------------
$milho_cultura = $_POST[milho_cultura];
if(isset($_POST[milho_cultura]))
{
	$milho_cultura = $_POST[milho_cultura];
}
else
{
	$milho_cultura  = 'N';
}
$milho_cultura_ha = $_POST[milho_cultura_ha];
if ($milho_cultura_ha != "")
{
	$milho_cultura_ha = explode(",",$_POST['milho_cultura_ha']);
	$milho_cultura_inteiro=str_replace('.','',$milho_cultura_ha[0]);
	$milho_cultura_ha=$milho_cultura_inteiro . '.' . $milho_cultura_ha[1];	
}
else
{
	$milho_cultura_ha = 0.0000;
}
//------------
$abacaxi_cultura = $_POST[abacaxi_cultura];
if(isset($_POST[abacaxi_cultura]))
{
	$abacaxi_cultura = $_POST[abacaxi_cultura];
}
else
{
	$abacaxi_cultura  = 'N';
}
$abacaxi_cultura_ha = $_POST[abacaxi_cultura_ha];
if ($abacaxi_cultura_ha != "")
{
	$abacaxi_cultura_ha = explode(",",$_POST['abacaxi_cultura_ha']);
	$abacaxi_cultura_inteiro=str_replace('.','',$abacaxi_cultura_ha[0]);
	$abacaxi_cultura_ha=$abacaxi_cultura_inteiro . '.' . $abacaxi_cultura_ha[1];	
}
else
{
	$abacaxi_cultura_ha = 0.0000;
}
//------------
$arroz_cultura = $_POST[arroz_cultura];
if(isset($_POST[arroz_cultura]))
{
	$arroz_cultura = $_POST[arroz_cultura];
}
else
{
	$arroz_cultura  = 'N';
}
$arroz_cultura_ha = $_POST[arroz_cultura_ha];
if ($arroz_cultura_ha != "")
{
	$arroz_cultura_ha = explode(",",$_POST['arroz_cultura_ha']);
	$arroz_cultura_inteiro=str_replace('.','',$arroz_cultura_ha[0]);
	$arroz_cultura_ha=$arroz_cultura_inteiro . '.' . $arroz_cultura_ha[1];	
}
else
{
	$arroz_cultura_ha = 0.0000;
}
//------------
$mamao_cultura = $_POST[mamao_cultura];
if(isset($_POST[mamao_cultura]))
{
	$mamao_cultura = $_POST[mamao_cultura];
}
else
{
	$mamao_cultura  = 'N';
}
$mamao_cultura_ha = $_POST[mamao_cultura_ha];
if ($mamao_cultura_ha != "")
{
	$mamao_cultura_ha = explode(",",$_POST['mamao_cultura_ha']);
	$mamao_cultura_inteiro=str_replace('.','',$mamao_cultura_ha[0]);
	$mamao_cultura_ha=$mamao_cultura_inteiro . '.' . $mamao_cultura_ha[1];	
}
else
{
	$mamao_cultura_ha = 0.0000;
}
//------------
$capim_cultura = $_POST[capim_cultura];
if(isset($_POST[capim_cultura]))
{
	$capim_cultura = $_POST[capim_cultura];
}
else
{
	$capim_cultura  = 'N';
}
$capim_cultura_ha = $_POST[capim_cultura_ha];
if ($capim_cultura_ha != "")
{
	$capim_cultura_ha = explode(",",$_POST['capim_cultura_ha']);
	$capim_cultura_inteiro=str_replace('.','',$capim_cultura_ha[0]);
	$capim_cultura_ha=$capim_cultura_inteiro . '.' . $capim_cultura_ha[1];	
}
else
{
	$capim_cultura_ha = 0.0000;
}
//------------
$coco_cultura = $_POST[coco_cultura];
if(isset($_POST[coco_cultura]))
{
	$coco_cultura = $_POST[coco_cultura];
}
else
{
	$coco_cultura  = 'N';
}
$coco_cultura_ha = $_POST[coco_cultura_ha];
if ($coco_cultura_ha != "")
{
	$coco_cultura_ha = explode(",",$_POST['coco_cultura_ha']);
	$coco_cultura_inteiro=str_replace('.','',$coco_cultura_ha[0]);
	$coco_cultura_ha=$coco_cultura_inteiro . '.' . $coco_cultura_ha[1];	
}
else
{
	$coco_cultura_ha = 0.00;
}
//------------
$feijao_cultura = $_POST[feijao_cultura];
if(isset($_POST[feijao_cultura]))
{
	$feijao_cultura = $_POST[feijao_cultura];
}
else
{
	$feijao_cultura  = 'N';
}
$feijao_cultura_ha = $_POST[feijao_cultura_ha];
if ($feijao_cultura_ha != "")
{
	$feijao_cultura_ha = explode(",",$_POST['feijao_cultura_ha']);
	$feijao_cultura_inteiro=str_replace('.','',$feijao_cultura_ha[0]);
	$feijao_cultura_ha=$feijao_cultura_inteiro . '.' . $feijao_cultura_ha[1];	
}
else
{
	$feijao_cultura_ha = 0.00;
}
//------------
$acerola_cultura = $_POST[acerola_cultura];
if(isset($_POST[acerola_cultura]))
{
	$acerola_cultura = $_POST[acerola_cultura];
}
else
{
	$acerola_cultura  = 'N';
}
$acerola_cultura_ha = $_POST[acerola_cultura_ha];
if ($acerola_cultura_ha != "")
{
	$acerola_cultura_ha = explode(",",$_POST['acerola_cultura_ha']);
	$acerola_cultura_inteiro=str_replace('.','',$acerola_cultura_ha[0]);
	$acerola_cultura_ha=$acerola_cultura_inteiro . '.' . $acerola_cultura_ha[1];	
}
else
{
	$acerola_cultura_ha = 0.00;
}
//------------
$caju_cultura = $_POST[caju_cultura];
if(isset($_POST[caju_cultura]))
{
	$caju_cultura = $_POST[caju_cultura];
}
else
{
	$caju_cultura  = 'N';
}
$caju_cultura_ha = $_POST[caju_cultura_ha];
if ($caju_cultura_ha != "")
{
	$caju_cultura_ha = explode(",",$_POST['caju_cultura_ha']);
	$caju_cultura_inteiro=str_replace('.','',$caju_cultura_ha[0]);
	$caju_cultura_ha=$caju_cultura_inteiro . '.' . $caju_cultura_ha[1];	
}
else
{
	$caju_cultura_ha = 0.00;
}
//------------
$mandioca_cultura = $_POST[mandioca_cultura];
if(isset($_POST[mandioca_cultura]))
{
	$mandioca_cultura = $_POST[mandioca_cultura];
}
else
{
	$mandioca_cultura  = 'N';
}
$mandioca_cultura_ha = $_POST[mandioca_cultura_ha];
if ($mandioca_cultura_ha != "")
{
	$mandioca_cultura_ha = explode(",",$_POST['mandioca_cultura_ha']);
	$mandioca_cultura_inteiro=str_replace('.','',$mandioca_cultura_ha[0]);
	$mandioca_cultura_ha=$mandioca_cultura_inteiro . '.' . $mandioca_cultura_ha[1];	
}
else
{
	$mandioca_cultura_ha = 0.00;
}
//------------
$uva_cultura = $_POST[uva_cultura];
if(isset($_POST[uva_cultura]))
{
	$uva_cultura = $_POST[uva_cultura];
}
else
{
	$uva_cultura  = 'N';
}
$uva_cultura_ha = $_POST[uva_cultura_ha];
if ($uva_cultura_ha != "")
{
	$uva_cultura_ha = explode(",",$_POST['uva_cultura_ha']);
	$uva_cultura_inteiro=str_replace('.','',$uva_cultura_ha[0]);
	$uva_cultura_ha=$uva_cultura_inteiro . '.' . $uva_cultura_ha[1];	
}
else
{
	$uva_cultura_ha = 0.00;
}
//------------
$ata_cultura = $_POST[ata_cultura];
if(isset($_POST[ata_cultura]))
{
	$ata_cultura = $_POST[ata_cultura];
}
else
{
	$ata_cultura  = 'N';
}
$ata_cultura_ha = $_POST[ata_cultura_ha];
if ($ata_cultura_ha != "")
{
	$ata_cultura_ha = explode(",",$_POST['ata_cultura_ha']);
	$ata_cultura_inteiro=str_replace('.','',$ata_cultura_ha[0]);
	$ata_cultura_ha=$ata_cultura_inteiro . '.' . $ata_cultura_ha[1];	
}
else
{
	$ata_cultura_ha = 0.00;
}
//------------
$macaxeira_cultura = $_POST[macaxeira_cultura];
if(isset($_POST[macaxeira_cultura]))
{
	$macaxeira_cultura = $_POST[macaxeira_cultura];
}
else
{
	$macaxeira_cultura  = 'N';
}
$macaxeira_cultura_ha = $_POST[macaxeira_cultura_ha];
if ($macaxeira_cultura_ha != "")
{
	$macaxeira_cultura_ha = explode(",",$_POST['macaxeira_cultura_ha']);
	$macaxeira_cultura_inteiro=str_replace('.','',$macaxeira_cultura_ha[0]);
	$macaxeira_cultura_ha=$macaxeira_cultura_inteiro . '.' . $macaxeira_cultura_ha[1];	
}
else
{
	$macaxeira_cultura_ha = 0.00;
}
//------------
$manga_cultura = $_POST[manga_cultura];
if(isset($_POST[manga_cultura]))
{
	$manga_cultura = $_POST[manga_cultura];
}
else
{
	$manga_cultura  = 'N';
}
$manga_cultura_ha = $_POST[manga_cultura_ha];
if ($manga_cultura_ha != "")
{
	$manga_cultura_ha = explode(",",$_POST['manga_cultura_ha']);
	$manga_cultura_inteiro=str_replace('.','',$manga_cultura_ha[0]);
	$manga_cultura_ha=$manga_cultura_inteiro . '.' . $manga_cultura_ha[1];	
}
else
{
	$manga_cultura_ha = 0.00;
}
//------------
$horta_cultura = $_POST[horta_cultura];
if(isset($_POST[horta_cultura]))
{
	$horta_cultura = $_POST[horta_cultura];
}
else
{
	$horta_cultura  = 'N';
}
$horta_cultura_ha = $_POST[horta_cultura_ha];
if ($horta_cultura_ha != "")
{
	$horta_cultura_ha = explode(",",$_POST['horta_cultura_ha']);
	$horta_cultura_inteiro=str_replace('.','',$horta_cultura_ha[0]);
	$horta_cultura_ha=$horta_cultura_inteiro . '.' . $horta_cultura_ha[1];	
}
else
{
	$horta_cultura_ha = 0.00;
}
//------------
$outra_cultura = $_POST[outra_cultura];

$outra_cultura_ha = $_POST[outra_cultura_ha];
if ($outra_cultura_ha != "")
{
	$outra_cultura_ha = explode(",",$_POST['outra_cultura_ha']);
	$outra_cultura_inteiro=str_replace('.','',$outra_cultura_ha[0]);
	$outra_cultura_ha=$outra_cultura_inteiro . '.' . $outra_cultura_ha[1];	
}
else
{
	$outra_cultura_ha = 0.0000;
}
$cultura_consorciada = $_POST[cultura_consorciada];
$cultura_consorciada_ha = $_POST[cultura_consorciada_ha];
if ($cultura_consorciada_ha != "")
{
	$cultura_consorciada_ha = explode(",",$_POST['cultura_consorciada_ha']);
	$cultura_consorciada_inteiro=str_replace('.','',$cultura_consorciada_ha[0]);
	$cultura_consorciada_ha=$cultura_consorciada_inteiro . '.' . $cultura_consorciada_ha[1];	
}
else
{
	$cultura_consorciada_ha = 0.0000;
}

//------------
$total_area_lote = 0;
$total_cultura = 0;
$sql_area_lote="SELECT codigo_lote, numero_lote,codigo_irrigante_lote,area_lote_ha, tipo_lote FROM lote WHERE codigo_irrigante_lote = '$codigo_irrigante_cultura'";
$qr_area_lote = pg_query($sql_area_lote);
$numregs_area_lote = pg_num_rows($qr_area_lote);

if($numregs_area_lote <= 0)
{
	echo"<script>alert('Área do irrigante não cadastrada!')</script>";        
	echo "<script>location='../grid.php?table=cultura';</script>";	
	exit;
}
else{
	while ($i < $numregs_area_lote)     
   	{
		$tipo_lote = pg_result($qr_area_lote,$i,'tipo_lote');						
		$area_lote_ha = pg_result($qr_area_lote,$i,'area_lote_ha');		
		switch ($tipo_lote)
		{ 
			case 'I': 
				$total_area_lote = $total_area_lote + $area_lote_ha;
			break; 								
			case 'S': 
				$total_area_lote = $total_area_lote + $area_lote_ha;
			break; 													
		}		
		$i++; 
	}
}

$total_cultura = ($banana_cultura_ha+$sorgo_cultura_ha+$goiaba_cultura_ha+$melancia_cultura_ha+$milho_cultura_ha+$abacaxi_cultura_ha+$arroz_cultura_ha+
$mamao_cultura_ha+$capim_cultura_ha+$coco_cultura_ha+$outra_cultura_ha+$cultura_consorciada_ha+$feijao_cultura_ha+$acerola_cultura_ha);

if($total_cultura > $total_area_lote)
{	
	echo "<script>alert('Área das culturas maior que a área total do lote!')</script>";        
	echo "<script>location='../grid.php?table=cultura';</script>";
	exit;
}

$table = 'cultura';

$strInsert = "INSERT INTO $table (codigo_cultura,codigo_irrigante_cultura,banana_cultura,banana_cultura_ha,sorgo_cultura,sorgo_cultura_ha,goiaba_cultura,
goiaba_cultura_ha,melancia_cultura,melancia_cultura_ha,milho_cultura,milho_cultura_ha,abacaxi_cultura,abacaxi_cultura_ha,arroz_cultura,arroz_cultura_ha,
mamao_cultura,mamao_cultura_ha,capim_cultura,capim_cultura_ha,coco_cultura,coco_cultura_ha,outra_cultura,outra_cultura_ha,cultura_consorciada,cultura_consorciada_ha,
feijao_cultura,feijao_cultura_ha,acerola_cultura,acerola_cultura_ha,caju_cultura,caju_cultura_ha,mandioca_cultura,mandioca_cultura_ha,uva_cultura,uva_cultura_ha,
ata_cultura,ata_cultura_ha,macaxeira_cultura,macaxeira_cultura_ha,manga_cultura,manga_cultura_ha,horta_cultura,horta_cultura_ha) 
	VALUES ('$codigo_cultura','$codigo_irrigante_cultura','$banana_cultura','$banana_cultura_ha','$sorgo_cultura','$sorgo_cultura_ha','$goiaba_cultura',
	'$goiaba_cultura_ha','$melancia_cultura','$melancia_cultura_ha','$milho_cultura','$milho_cultura_ha','$abacaxi_cultura','$abacaxi_cultura_ha',
	'$arroz_cultura','$arroz_cultura_ha','$mamao_cultura','$mamao_cultura_ha','$capim_cultura','$capim_cultura_ha','$coco_cultura','$coco_cultura_ha',
	'$outra_cultura','$outra_cultura_ha','$cultura_consorciada','$cultura_consorciada_ha','$feijao_cultura','$feijao_cultura_ha','$acerola_cultura','$acerola_cultura_ha',
	'$caju_cultura','$caju_cultura_ha','$mandioca_cultura','$mandioca_cultura_ha','$uva_cultura','$uva_cultura_ha','$ata_cultura','$ata_cultura_ha','$macaxeira_cultura',
	'$macaxeira_cultura_ha','$manga_cultura','$manga_cultura_ha','$horta_cultura','$horta_cultura_ha')";

	if($sgbd=='my'){
		$insert = mysql_query($strInsert);
	}elseif($sgbd=='pg'){
		$insert = pg_query($strInsert);
	}

	if (!$insert){
		if($sgbd=='my'){
			echo mysql_error()."Erro: Falha ao inserir o registro!";
			exit;
		}elseif($sgbd=='pg'){
			echo pg_last_error()."Erro: Falha ao inserir o registro!";
			exit;
		}
	}

	echo "<script>location='../grid.php?table=cultura';</script>";
	?>
	