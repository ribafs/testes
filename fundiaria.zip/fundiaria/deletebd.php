<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
<?php 	
session_start();
if(!isset($_SESSION['access'])){
	print 'Direct Access denied!';
	exit;
}

if ($_SESSION['admin'] <> 's')
{	echo" <script>alert('Usuário não possui autorização para excluir.');</script>";
	echo "<script>location='menu.php';</script>";	
}
else
{
include_once("./includes/connection.inc.php"); 
include_once("./includes/functions.inc.php");

	$table = $_GET['table'];

	$c=0;
	$count = count(primary_key($table));
	foreach(primary_key($table) as $p){
		if($c < $count-1){
			$pk .= $p . ',';
		}else{
			$pk .= $p;
		}
		$c ++;
	}

	$pk0 = explode(',',$pk);

	if($count ==1){
		$pk1=$pk0[0];
		$value1 = $_GET[$pk1];
		$value = "$pk1 = '$value1'";
	}elseif($count ==2){
		$pk1=$pk0[0];
		$pk2=$pk0[1];

		$value1 = $_GET[$pk1];
		$value2 = $_GET[$pk2];
		$value = "$pk1 = '$value1' AND $pk2 = '$value2'";
	}

	if($sgbd=='my'){
		mysql_query("DELETE FROM $table WHERE $value") or die(mysql_error());
		echo "<script>location='grid.php?table=$table';</script>";
	}elseif($sgbd=='pg'){
		pg_query("DELETE FROM $table WHERE $value") or die(pg_last_error());
		echo "<script>location='grid.php?table=$table';</script>";
	}	
}
?>

