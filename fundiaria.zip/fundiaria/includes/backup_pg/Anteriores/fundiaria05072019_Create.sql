-- Structure for table 'ab_fundiaria'
CREATE TABLE ab_fundiaria (descricao varchar(25),valor_ha numeric);

-- Structure for table 'acesso'
CREATE TABLE acesso(login character(12) NOT NULL,password character(32) NOT NULL,admin character(1) NOT NULL,CONSTRAINT acesso_pkey PRIMARY KEY (login)) WITH (OIDS=FALSE); 
ALTER TABLE acesso   OWNER TO postgres;

-- Structure for table 'animais_servico'
CREATE TABLE animais_servico(codigo_animal serial NOT NULL,codigo_irrigante_animal character varying(8) NOT NULL,descricao_animal character varying(20),quantidade_animal numeric(3,0),CONSTRAINT animal PRIMARY KEY (codigo_animal))
WITH (OIDS=FALSE); ALTER TABLE animais_servico OWNER TO postgres;

-- Structure for table 'aquisicao_lote'
CREATE TABLE aquisicao_lote(sigla_aquisicao character varying(1) NOT NULL, descricao_aquisicao character varying(15),  CONSTRAINT aquisicao_lote_pkey PRIMARY KEY (sigla_aquisicao))
WITH (OIDS=FALSE); ALTER TABLE aquisicao_lote   OWNER TO postgres;

-- Structure for table "cadastro_da_rebate"
CREATE TABLE "cadastro_da_rebate" (codigo_da_rebate serial NOT NULL,nome_da_rebate character varying(50),rg_da_rebate character varying(50),cpf_da_rebate character varying(14),
CONSTRAINT codigo_da_rebate_pkey PRIMARY KEY (codigo_da_rebate)) WITH (OIDS=FALSE); ALTER TABLE "cadastro_da_rebate"   OWNER TO postgres;

-- Structure for table 'comissao_fundiaria'
CREATE TABLE comissao_fundiaria (codigo_comissao varchar(50) NOT NULL,portaria_comissao varchar(60),presidente_comissao varchar(60),membro1_comissao varchar(60),
membro2_comissao varchar(60),membro3_comissao varchar(60),data_comissao date,  presidente_gtrf character varying(60), CONSTRAINT codigo_comissao_pkey PRIMARY KEY (codigo_comissao))
WITH (OIDS=FALSE); ALTER TABLE comissao_fundiaria  OWNER TO postgres;

-- Structure for table 'cultura' 
CREATE TABLE cultura(codigo_cultura serial NOT NULL,codigo_irrigante_cultura serial NOT NULL,banana_cultura character(1),banana_cultura_ha numeric(4,2),sorgo_cultura character(1),sorgo_cultura_ha numeric(4,2),
goiaba_cultura character(1),goiaba_cultura_ha numeric(4,2),melancia_cultura character(1),melancia_cultura_ha numeric(4,2),milho_cultura character(1),milho_cultura_ha numeric(4,2),abacaxi_cultura character(1),
abacaxi_cultura_ha numeric(4,2),arroz_cultura character(1),arroz_cultura_ha numeric(4,2),mamao_cultura character(1),mamao_cultura_ha numeric(4,2),capim_cultura character(1),capim_cultura_ha numeric(4,2),
coco_cultura character(1),coco_cultura_ha numeric(4,2),outra_cultura character(20),outra_cultura_ha numeric(4,2),cultura_consorciada character varying(20),cultura_consorciada_ha numeric(4,2),
feijao_cultura character varying(1),feijao_cultura_ha numeric(4,2),acerola_cultura character varying(1),acerola_cultura_ha numeric(4,2),caju_cultura character varying(1),caju_cultura_ha numeric(4,2),
mandioca_cultura character varying(1),mandioca_cultura_ha numeric(4,2),uva_cultura character varying(1),uva_cultura_ha numeric(4,2),ata_cultura character varying(1),ata_cultura_ha numeric(4,2),
macaxeira_cultura character varying(1),macaxeira_cultura_ha numeric(4,2),manga_cultura character(1),manga_cultura_ha numeric(4,2),horta_cultura character varying(1),horta_cultura_ha numeric(4,2),
CONSTRAINT cultura_pkey PRIMARY KEY (codigo_cultura)) WITH (OIDS=FALSE);  ALTER TABLE cultura OWNER TO postgres;
  
-- Table: estado_civil
CREATE TABLE estado_civil( sigla_estado_civil character varying(2) NOT NULL,descricao_estado_civil character varying(30),
CONSTRAINT estado_civil_pkey PRIMARY KEY (sigla_estado_civil)) WITH (OIDS=FALSE); ALTER TABLE estado_civil  OWNER TO postgres;

-- Structure for table 'estados'
CREATE TABLE estados (sigla character varying(2) NOT NULL, descricao character varying(30) NOT NULL, CONSTRAINT primarykey PRIMARY KEY (sigla)) WITH ( OIDS=FALSE );
ALTER TABLE estados OWNER TO postgres;

-- Structure for table 'exploracao_pecuaria'
CREATE TABLE exploracao_pecuaria(codigo_pecuaria serial NOT NULL,codigo_irrigante_pecuaria serial NOT NULL,bovino_pecuaria character(1),caprino_pecuaria character(1),ave_pecuaria character(1),
  ovino_pecuaria character(1),outra__pecuaria character(20),nenhuma_pecuaria character varying(1),carcinicultura_pecuaria character varying(1),psicultura_pecuaria character varying(1),
  suinocultura_pecuaria character varying(1),apicultura_pecuaria character varying(1),apicultura_pecuaria_quantidade character varying(3),bovino_pecuaria_quantidade character varying(3),
  caprino_pecuaria_quantidade character varying(3),ave_pecuaria_quantidade character varying(3),ovino_pecuaria_quantidade character varying(3),carcinicultura_pecuaria_quantidade character varying(3),
  psicultura_pecuaria_quantidade character varying(3),suinocultura_pecuaria_quantidade character varying(3),outra__pecuaria_quantidade character varying(3),
  CONSTRAINT exploracao_pecuaria_pkey PRIMARY KEY (codigo_pecuaria)) WITH (OIDS=FALSE); ALTER TABLE exploracao_pecuaria OWNER TO postgres;  
  
-- Structure for table 'ferramenta'
CREATE TABLE ferramenta(codigo_ferramenta serial NOT NULL,codigo_irrigante_ferramenta serial NOT NULL,descricao_ferramenta character varying(25),quantidade_ferramenta numeric(4,0),CONSTRAINT ferramenta_pkey PRIMARY KEY (codigo_ferramenta))
WITH (OIDS=FALSE); ALTER TABLE ferramenta   OWNER TO postgres;

-- Structure for table 'instalacao'
CREATE TABLE instalacao(codigo_instalacao serial NOT NULL,codigo_irrigante_instalacao serial NOT NULL,descricao_instalacao character varying(20),area_instalacao numeric(8,2),CONSTRAINT instalacao_pkey PRIMARY KEY (codigo_instalacao))
WITH (OIDS=FALSE); ALTER TABLE instalacao OWNER TO postgres;

-- Structure for table 'irrigante'
CREATE TABLE irrigante (codigo_irrigante serial NOT NULL,cpf_irrigante character varying(14),nome_irrigante character varying(60),codigo_irrigante_perimetro serial NOT NULL,
  localizacao_irrigante character varying(20),apelido_irrigante character varying(15),rg_irrigante character varying(40),endereco_irrigante character varying(60),
  complemento_irrigante character varying(50),municipio_irrigante character varying(25),cep_irrigante character varying(9),estado_civil_irrigante character varying(12),
  data_nascimento_irrigante date,nome_conjuge_irrigante character varying(60),cpf_conjuge_irrigante character varying(14),nome_pai_irrigante character varying(60),
  cpf_pai_irrigante character varying(14),nome_mae_irrigante character varying(60),cpf_mae_irrigante character varying(14),codigo_irrigante_organizacao serial NOT NULL,
  unidade_campo_irrigante character varying(10),numero_processo character varying(25),possui_eletricidade character varying(3),telefone_irrigante character varying(14),
  celular_irrigante character varying(14),numero_car_irrigante character varying(60),municipio_naturalidade_irrigante character varying(30),estado_unidade character varying(2),
  data_entrada_lote date, data_informacao date, CONSTRAINT irrigante_pkey PRIMARY KEY (codigo_irrigante)) WITH (OIDS=FALSE); ALTER TABLE irrigante OWNER TO postgres;  
  
-- Structure for table 'irrigante_dependente'
CREATE TABLE irrigante_dependente(codigo_dependente serial NOT NULL,codigo_irrigante_dependente serial NOT NULL,nome_dependente character varying(60),grauu_parentesco_dependente character varying(20),data_nascimento_dependente date,
CONSTRAINT irrigante_dependente_pkey PRIMARY KEY (codigo_dependente)) WITH (OIDS=FALSE); ALTER TABLE irrigante_dependente  OWNER TO postgres;

-- Structure for table 'lote'
CREATE TABLE lote (numero_lote character varying(20),codigo_irrigante_lote integer NOT NULL,area_lote_ha numeric(8,4),valor_do_lote numeric(8,2),confinante_lote_norte character varying(60),
  confinante_lote_leste character varying(60),confinante_lote_sul character varying(60),confinante_lote_oeste character varying(60),forma_aquisicao_lote character varying(13),
  data_aquisicao_lote date,tipo_lote character varying(15),acesso_lote character varying(50),tipo_casa character varying(5),area_casa_m2 numeric(5,2),
  codigo_lote integer NOT NULL,localizacao_lote character varying(20),lote_incra character varying(20),CONSTRAINT primarykey_lote PRIMARY KEY (codigo_lote))
WITH (OIDS=FALSE); ALTER TABLE lote OWNER TO postgres; 
  
-- Structure for table 'maquina_implemento'
CREATE TABLE maquina_implemento(codigo_maquina serial NOT NULL,codigo_irrigante_maquina serial NOT NULL,descricao_maquina character varying(30),quantidade_maquina numeric(4,2),CONSTRAINT maquina_implemento_pkey PRIMARY KEY (codigo_maquina))
WITH (OIDS=FALSE); ALTER TABLE maquina_implemento OWNER TO postgres;

-- Structure for table 'organizacao_produtores'
CREATE TABLE organizacao_produtores (codigo_organizacao serial NOT NULL,sigla_organizacao character varying(15),descricao_organizacao character varying(90),nome_presidente_organizacao character varying(60),
  cnpj_organizacao character varying(20),endereco_organizacao character varying(70),telefone_organizacao character varying(14),celular_organizacao character varying(14),email_organizacao character varying(50),
  cep_organizacao_produtores character varying(9),municipio_organizacao_produtores character varying(25),estado_organizacao_produtores character varying(2),
  CONSTRAINT organizacao_produtores_pkey PRIMARY KEY (codigo_organizacao)) WITH (OIDS=FALSE); ALTER TABLE organizacao_produtores OWNER TO postgres;

-- Structure for table 'perimetro'
CREATE TABLE perimetro(codigo_perimetro serial NOT NULL,descricao_perimetro character varying(60), localizacao_perimetro character varying(30),estado_perimetro character varying(10),
  area_perimetro numeric(8,2),matricula_unica character varying(15),matricula_unificada character varying(3),numero_car_perimetro character varying(60),
  CONSTRAINT perimetro_pkey PRIMARY KEY (codigo_perimetro)) WITH (OIDS=FALSE ); ALTER TABLE perimetro OWNER TO postgres;  
  
-- Structure for table 'sistema_irrigacao'
CREATE TABLE sistema_irrigacao(codigo_irrigacao serial NOT NULL,codigo_irrigante_irrigacao serial NOT NULL,sulco_irrigacao character(1),gotejamento_irrigacao character(1),microaspersao_irrigacao character(1),inundacao_irrigacao character(1),
pivo_central_irrigacao character(1),aspersao_convencional character(1),outro_irrigacao character varying(20),superficie_irrigacao character varying(1),CONSTRAINT sistema_irrigacao_pkey PRIMARY KEY (codigo_irrigacao)) WITH (OIDS=FALSE); ALTER TABLE sistema_irrigacao OWNER TO postgres;

-- Structure for table 'situacao_fundiaria'
CREATE TABLE situacao_fundiaria (codigo_situacao serial NOT NULL,codigo_irrigante_situacao serial NOT NULL,situacao_numero_contrato character varying(30),data_contrato_situacao date,data_publicacao_situacao date,
  tipo_contrato_situacao character varying(4), situacao_cartorio character varying(60), CONSTRAINT situacao_fundiaria_pkey PRIMARY KEY (codigo_situacao)) WITH (OIDS=FALSE); ALTER TABLE situacao_fundiaria  OWNER TO postgres;

-- Structure for table 'tipos_contratos'
CREATE TABLE tipos_contratos(sigla_tipo_contrato character varying(4),descricao_tipo_contrato character varying(60)) WITH (OIDS=FALSE); ALTER TABLE tipos_contratos   OWNER TO postgres;

-- Structure for table 'tipo_lote'
CREATE TABLE tipo_lote (sigla_lote character varying(1), descricao_tipo_lote character varying(12)) WITH (OIDS=FALSE); ALTER TABLE tipo_lote  OWNER TO postgres;

-- Structure for table 'unidade_administrativa'
CREATE TABLE unidade_administrativa (sigla_adm character varying(8) NOT NULL, descricao_adm character varying(60), CONSTRAINT unidade_administrativa_pkey PRIMARY KEY (sigla_adm) ) 
WITH (OIDS=FALSE ); ALTER TABLE unidade_administrativa OWNER TO postgres; 

-- Structure for table 'unidade_campo'
CREATE TABLE unidade_campo (codigo_unidade integer NOT NULL, descricao_unidade character varying(60), unidade_adm character varying(20), chefe_unidade character varying(60), endereco_unidade character(60),
  cep_unidade character varying(10), telefone_unidade character varying(14), email_unidade character varying(50), municipio_unidade character varying(40), estado_unidade character varying(10),
  CONSTRAINT unidade PRIMARY KEY (codigo_unidade)) WITH ( OIDS=FALSE ); ALTER TABLE unidade_campo OWNER TO postgres;

