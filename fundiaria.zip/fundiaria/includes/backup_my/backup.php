<?php
include_once("../connection.inc.php");
include_once("../functions.inc.php");

/* Backup from database MySQL
$tables:
'' - to tables without relationship
$tablesarray in correct order: without relationship before, after with
$tables=array('acesso','produtos', 'clientes','funcionarios','pedidos','pedido_itens');
*/

function mysql_backup($tables){
	global $database;
	$file = $database.".sql";
	$back = fopen($file,"w");

	if($tables !=''){
		$count = count($tables);
	}else{
		$tables = table_names();
		$tables = explode(',',$tables);
		$count = count($tables)-1;
	}

	$sql = '';
	for($x=0;$x<$count;$x++){
		$res2 = mysql_query("SHOW CREATE TABLE $tables[$x]");

		while ( $lin = mysql_fetch_row($res2)){
			$sql .="\n#\n# Create Tables : $table[$x]\n#\n\n";
			$sql .="$lin[1];\n\n#\n# Inserting datas in table\n#\n\n";
			$res3 = mysql_query("SELECT * FROM $tables[$x]");

			while($r=mysql_fetch_row($res3)){
				$sql .="INSERT INTO $tables[$x] VALUES (";
				for($j=0; $j<mysql_num_fields($res3);$j++)
				{
					if(!isset($r[$j]))
					$sql .= " ,";
					elseif($r[$j] != "")
					$sql .= " '".addslashes($r[$j])."',";
					else
					$sql .= " ,";
				}
				$sql = ereg_replace(",$", "", $sql);
				$sql .= ");\n";			
			}
		}
	}

	$ret=fwrite($back,$sql);
	if(!$ret) print "Error on create file!";

	// fechar o arquivo que foi gravado
	fclose($back);
	// Adapted from: http://www.devmedia.com.br/articles/viewcomp.asp?comp=3925
}

//$tables=array('acesso','clientes','funcionarios','pedidos','pedido_itens','produtos');   // with relationship
$tables = ''; // without relationship

mysql_backup($tables);
?>

