<?php
	session_start();
	if(!isset($_SESSION['admin'])){
		print "Acesso direto negado!";
		exit;
	}
	include_once('../includes/connection.inc.php');
	include_once('../includes/functions.inc.php');
	$codigo_comissao = $_POST[codigo_comissao];
$portaria_comissao = $_POST[portaria_comissao];
$presidente_comissao = $_POST[presidente_comissao];
$membro1_comissao = $_POST[membro1_comissao];
$membro2_comissao = $_POST[membro2_comissao];
$membro3_comissao = $_POST[membro3_comissao];
$presidente_gtrf = $_POST[presidente_gtrf];

$data_comissao = $_POST[data_comissao];
if ($data_comissao != "")
{	
	$datefield = explode('/',$_POST[data_comissao]);
	$data_comissao = $datefield[2].'-'.$datefield[1].'-'.$datefield[0];
}

$table = 'comissao_fundiaria';

	// Support to multiple primary key
		$c=0;
		$count = count(primary_key($table));
		foreach(primary_key($table) as $p){
			if($c < $count-1){
				$pk .= $p . ',';
			}else{
				$pk .= $p;
			}
			$c ++;
		}

		$pk0 = explode(',',$pk);

	if($count ==1){
		$pk1=$pk0[0];
		$value1 = $_POST[$pk1];
		$value = "$pk1 = '$value1'";
	}elseif($count ==2){
		$pk1=$pk0[0];
		$pk2=$pk0[1];

		$value1 = $_POST[$pk1];
		$value2 = $_POST[$pk2];
		$value = "$pk1 = '$value1' AND $pk2 = '$value2'";
	}

if ($data_comissao != "//")
{		
	$strUpdate="UPDATE $table SET codigo_comissao = '$codigo_comissao', portaria_comissao = '$portaria_comissao', presidente_comissao = '$presidente_comissao', membro1_comissao = '$membro1_comissao', membro2_comissao = '$membro2_comissao', membro3_comissao = '$membro3_comissao', data_comissao = '$data_comissao', presidente_gtrf = '$presidente_gtrf' WHERE $value ";
}
else
{
	$strUpdate="UPDATE $table SET codigo_comissao = '$codigo_comissao', portaria_comissao = '$portaria_comissao', presidente_comissao = '$presidente_comissao', membro1_comissao = '$membro1_comissao', membro2_comissao = '$membro2_comissao', membro3_comissao = '$membro3_comissao',presidente_gtrf = '$presidente_gtrf' WHERE $value ";
}
	if($sgbd=='my'){
		mysql_query($strUpdate) or die(mysql_error());
	}elseif($sgbd=='pg'){
		pg_query($strUpdate) or die(pg_last_error());
	}
	echo "<script>location='../grid.php?table=$table'</script>";
	?>
	