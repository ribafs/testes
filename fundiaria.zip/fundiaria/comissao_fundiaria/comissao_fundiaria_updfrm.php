<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
<?php
error_reporting(0);
ini_set(“display_errors”, 0 );
?>

	<?php
	
	session_start();
	//if(!isset($_SESSION['access'])){
	//	print "Acesso direto negado!";
	//	exit;
	//}
	if ($_SESSION['admin'] <> 's')
	{
		echo" <script>alert('Usuário não possui autorização para editar.');</script>";
		echo "<script>location='../menu.php';</script>";			
	}

	include_once('../includes/lang.php'); 
	if($lang=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif($lang=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/connection.inc.php');
	include_once('../includes/header2.php');
	include_once('../includes/functions.inc.php');
	include_once('../includes/includes.html');

		$table = 'comissao_fundiaria';
		$c=0;
		$count = count(primary_key($table));
		foreach(primary_key($table) as $p){
			if($c < $count-1){
				$pk .= $p . ',';
			}else{
				$pk .= $p;
			}
			$c ++;
		}

		$pk0 = explode(',',$pk);

		if($count ==1){
			$pk1=$pk0[0];
			$value1 = $_GET[$pk1];
			$value = "$pk1 = '$value1'";
		}elseif($count ==2){
			$pk1=$pk0[0];
			$pk2=$pk0[1];

			$value1 = $_GET[$pk1];
			$value2 = $_GET[$pk2];
			$value = "$pk1 = '$value1' AND $pk2 = '$value2'";
		}

		$sql = "SELECT * FROM $table where $value";	
	

		if($sgbd == 'my'){
			$qry = mysql_query($sql);
			$reg = mysql_fetch_array($qry);
		}elseif($sgbd == 'pg'){
			$qry = pg_query($sql);
			$reg = pg_fetch_array($qry);
		}
	if($sgbd == 'my'){
		$nf=mysql_num_fields($qry);
		for($x=0;$x<$nf;$x++){
			$type = mysql_field_type($qry,$x);
			if($type == 'date'){
				$datefield = explode('-',$reg[$x]);
				$reg[$x] = $datefield[2].'/'.$datefield[1].'/'.$datefield[0];
				$dataget = $reg[$x];
			}
		}
	}elseif($sgbd == 'pg'){
		$nf=pg_num_fields($qry);
		for($x=0;$x<$nf;$x++){
			$type = pg_field_type($qry,$x);
			if($type == 'date'){
				$datefield = explode('-',$reg[$x]);
				$reg[$x] = $datefield[2].'/'.$datefield[1].'/'.$datefield[0];
				$dataget = $reg[$x];
			}
		}
	}
	?>
<script>
        function mascara_data_comissao(data_comissao){ 
              var mydata_nascimento = ''; 
              mydata_nascimento = mydata_nascimento + data_comissao; 
              if (mydata_nascimento.length == 2){ 
                  mydata_nascimento = mydata_nascimento + '/'; 
                  document.forms[0].data_comissao.value = mydata_nascimento; 
              } 
              if (mydata_nascimento.length == 5){ 
                  mydata_nascimento = mydata_nascimento + '/'; 
                  document.forms[0].data_comissao.value = mydata_nascimento; 
              } 
              if (mydata_nascimento.length == 10){ 
                  verifica_data_comissao(); 
              } 
        } 
    </script>
	<script>
        function verifica_data_aquisicao_lote) { 

            dia_nascimento = (document.forms[0].data_comissao.value.substring(0,2)); 
            mes_nascimento = (document.forms[0].data_comissao.value.substring(3,5)); 
            ano_nascimento = (document.forms[0].data_comissao.value.substring(6,10)); 

            situacao_nascimento = ""; 
            // verifica o dia valido para cada mes 
            if ((dia_nascimento < 01)||(dia_nascimento < 01 || dia_nascimento > 30) && (  mes_nascimento == 04 || mes_nascimento == 06 || mes_nascimento == 09 || mes_nascimento == 11 ) || dia_nascimento > 31) { 
                situacao_nascimento = "falsa"; 
            } 

            // verifica se o mes e valido 
            if (mes_nascimento < 01 || mes_nascimento > 12 ) { 
                situacao_nascimento = "falsa"; 
            } 

            // verifica se e ano bissexto 
            if (mes_nascimento == 2 && ( dia_nascimento < 01 || dia_nascimento > 29 || ( dia_nascimento > 28 && (parseInt(ano_nascimento / 4) != ano_nascimento / 4)))) { 
                situacao_nascimento = "falsa"; 
            } 
    
            if (document.forms[0].data_comissao.value == "") { 
                situacao_nascimento = "falsa"; 
            } 
    
            if (situacao_nascimento == "falsa") { 
                alert("Data inválida!"); 
                document.forms[0].data_comissao.focus(); 
            } 
          }
          
    </script>	
	
	<script src="../includes/validate/jquery.validationEngine_br.js" type="text/javascript"></script>
	
	<body onLoad="document.frmUpdate..focus()">
	<br><br>
	<h2 align=center><?php echo 'Editar ' .ucfirst(Comissão);?></h2>
<br><br>
	<form name="frm_comissao_fundiaria" method="post" action="comissao_fundiaria_upddb.php" id="test">
<table border="0" align="center">
		<input type="hidden" name="data2" value="<?php echo $dataget;?>">
		<table border="0" align="center">
		<tr><td>Código: </td><td><input name="codigo_comissao" type="text" size="50" maxlength="50" onFocus="status_msg.value='Campo codigo_comissao'" onBlur="status_msg.value=''" value="<?php echo trim($reg[0]);?>"></td></tr>
	<tr><td>Portaria: </td><td><input name="portaria_comissao" type="text" size="60" maxlength="60" onFocus="status_msg.value='Campo portaria_comissao'" onBlur="status_msg.value=''" value="<?php echo trim($reg[1]);?>"></td></tr>	
	<tr><td>Data Portaria: </td><td><input name="data_comissao" type="text" size="10" maxlength="10" value="<?php echo trim($reg[6]);?>" OnKeyUp="mascara_data_comissao(this.value)" onFocus="" onBlur="status_msg.value=''"></td></tr>        						
	<tr><td>Presidente</td><td><input name="presidente_comissao" type="text" size="60" maxlength="60" onFocus="status_msg.value='Campo presidente_comissao'" onBlur="status_msg.value=''" value="<?php echo trim($reg[2]);?>"></td></tr>
	<tr><td>Membro1</td><td><input name="membro1_comissao" type="text" size="60" maxlength="60" onFocus="status_msg.value='Campo membro1_comissao'" onBlur="status_msg.value=''" value="<?php echo trim($reg[3]);?>"></td></tr>
	<tr><td>Membro2</td><td><input name="membro2_comissao" type="text" size="60" maxlength="60" onFocus="status_msg.value='Campo membro2_comissao'" onBlur="status_msg.value=''" value="<?php echo trim($reg[4]);?>"></td></tr>
	<tr><td>Membro3</td><td><input name="membro3_comissao" type="text" size="60" maxlength="60" onFocus="status_msg.value='Campo membro3_comissao'" onBlur="status_msg.value=''" value="<?php echo trim($reg[5]);?>"></td></tr>
	<tr><td>presidente_gtrf</td><td><input name="presidente_gtrf" type="text" size="60" maxlength="60"  onBlur="status_msg.value=''" value="<?php echo trim($reg[7]);?>"></td></tr>
	<tr><td></td><td><input type="submit" class="submit" value="Atualizar"></td></tr>
		<tr><td colspan="2"><input type="text" id="status_msg" name="status_msg" value="membro3_comissao" size="60" readonly></td></tr>
	</table>
	</form>

	<?php 
	include_once("../includes/footer2.php"); 
	?>
	