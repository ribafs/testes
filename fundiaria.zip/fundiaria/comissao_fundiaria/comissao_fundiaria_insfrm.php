<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
	<?php 	
	//session_start();
	//if(!isset($_SESSION['access'])){
	//	print "Acesso direto negado!";
	//	exit;
	//}
	include_once('../includes/lang.php'); 
	if($lang=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif($lang=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/connection.inc.php');
	include_once('../includes/header2.php');
	include_once('../includes/functions.inc.php');
	include_once('../includes/includes.html');
	
	$strconsulta = pg_exec("SELECT MAX(codigo_comissao) AS codigo FROM comissao_fundiaria");
	$cd_codigo=(pg_result($strconsulta,0,'codigo')+1);
	?>
	
	<script>
        function mascara_data_comissao(data_comissao){ 
              var mydata_nascimento = ''; 
              mydata_nascimento = mydata_nascimento + data_comissao; 
              if (mydata_nascimento.length == 2){ 
                  mydata_nascimento = mydata_nascimento + '/'; 
                  document.forms[0].data_comissao.value = mydata_nascimento; 
              } 
              if (mydata_nascimento.length == 5){ 
                  mydata_nascimento = mydata_nascimento + '/'; 
                  document.forms[0].data_comissao.value = mydata_nascimento; 
              } 
              if (mydata_nascimento.length == 10){ 
                  verifica_data_comissao(); 
              } 
        } 
    </script>
	<script>
        function verifica_data_aquisicao_lote) { 

            dia_nascimento = (document.forms[0].data_comissao.value.substring(0,2)); 
            mes_nascimento = (document.forms[0].data_comissao.value.substring(3,5)); 
            ano_nascimento = (document.forms[0].data_comissao.value.substring(6,10)); 

            situacao_nascimento = ""; 
            // verifica o dia valido para cada mes 
            if ((dia_nascimento < 01)||(dia_nascimento < 01 || dia_nascimento > 30) && (  mes_nascimento == 04 || mes_nascimento == 06 || mes_nascimento == 09 || mes_nascimento == 11 ) || dia_nascimento > 31) { 
                situacao_nascimento = "falsa"; 
            } 

            // verifica se o mes e valido 
            if (mes_nascimento < 01 || mes_nascimento > 12 ) { 
                situacao_nascimento = "falsa"; 
            } 

            // verifica se e ano bissexto 
            if (mes_nascimento == 2 && ( dia_nascimento < 01 || dia_nascimento > 29 || ( dia_nascimento > 28 && (parseInt(ano_nascimento / 4) != ano_nascimento / 4)))) { 
                situacao_nascimento = "falsa"; 
            } 
    
            if (document.forms[0].data_comissao.value == "") { 
                situacao_nascimento = "falsa"; 
            } 
    
            if (situacao_nascimento == "falsa") { 
                alert("Data inválida!"); 
                document.forms[0].data_comissao.focus(); 
            } 
          }
          
    </script>
		
	<script src="../includes/validate/jquery.validationEngine_br.js" type="text/javascript"></script>
	<body onLoad="document.frmInsert.codigo_comissao.focus()">
	<br>
	<br>
	<h2 align=center><?php echo Adicionar.' '.ucfirst(Comissão);?></h2>
<br>
<br>
	<form method="POST" id="test" action="comissao_fundiaria_insdb.php" name="frmInsert">
	<table border="0" align="center">
	<tr><td>Codigo Comissao</td><td><input name="codigo_comissao" type="text" size="50" maxlength="50" onFocus="status_msg.value='Campo codigo_comissao'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Portaria: </td><td><input name="portaria_comissao" type="text" size="60" maxlength="60" onFocus="status_msg.value='Campo portaria_comissao'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Data Portaria: </td><td><input name="data_comissao" type="text" size="10" maxlength="10" value="<?php echo $data_comissao;?>" OnKeyUp="mascara_data_comissao(this.value)" onFocus="" onBlur="status_msg.value=''"></td></tr>        					
	<tr><td>Presidente: </td><td><input name="presidente_comissao" type="text" size="60" maxlength="60" onFocus="status_msg.value='Campo presidente_comissao'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Membro1: </td><td><input name="membro1_comissao" type="text" size="60" maxlength="60" onFocus="status_msg.value='Campo membro1_comissao'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Membro2: </td><td><input name="membro2_comissao" type="text" size="60" maxlength="60" onFocus="status_msg.value='Campo membro2_comissao'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Membro3: </td><td><input name="membro3_comissao" type="text" size="60" maxlength="60" onFocus="status_msg.value='Campo membro3_comissao'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Presidente GTRF </td><td><input name="presidente_gtrf" type="text" size="60" maxlength="60"  onBlur="status_msg.value=''"></td></tr>
	<tr><td></td><td><input type="submit" class="submit" value="Inserir"></td></tr>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
		<tr><td colspan="2"><input type="text" id="status_msg" name="status_msg" value="membro3_comissao" size="60" readonly></td></tr>
	</table>

	</form>

	<?php 
	include_once("../includes/footer2.php"); 
	?>
	