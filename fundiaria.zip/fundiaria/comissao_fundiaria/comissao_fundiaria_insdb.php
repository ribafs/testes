<?php
	session_start();
	if(!isset($_SESSION['access'])){
		print "Acesso direto negado!";
		exit;
	}
	include_once('../includes/connection.inc.php');
	include_once('../includes/functions.inc.php');

$codigo_comissao = $_POST[codigo_comissao];
$portaria_comissao = $_POST[portaria_comissao];
$presidente_comissao = $_POST[presidente_comissao];
$membro1_comissao = $_POST[membro1_comissao];
$membro2_comissao = $_POST[membro2_comissao];
$membro3_comissao = $_POST[membro3_comissao];
$presidente_gtrf = $_POST[presidente_gtrf];

$data_comissao = $_POST[data_comissao];
if ($data_comissao != "")
{	
	$datefield = explode('/',$_POST[data_comissao]);
	$data_comissao = $datefield[2].'-'.$datefield[1].'-'.$datefield[0];
}

$table = 'comissao_fundiaria';

if ($data_comissao != "")
{
	$strInsert = "INSERT INTO $table (codigo_comissao,portaria_comissao,presidente_comissao,membro1_comissao,membro2_comissao,membro3_comissao,data_comissao,presidente_gtrf) 
		VALUES ('$codigo_comissao','$portaria_comissao','$presidente_comissao','$membro1_comissao','$membro2_comissao','$membro3_comissao','$data_comissao','$presidente_gtrf')";
}
else
{
	$strInsert = "INSERT INTO $table (codigo_comissao,portaria_comissao,presidente_comissao,membro1_comissao,membro2_comissao,membro3_comissao,presidente_gtrf) 
		VALUES ('$codigo_comissao','$portaria_comissao','$presidente_comissao','$membro1_comissao','$membro2_comissao','$membro3_comissao','$presidente_gtrf')";
}	

if($sgbd=='my'){
	$insert = mysql_query($strInsert);
}elseif($sgbd=='pg'){
	$insert = pg_query($strInsert);
}
if (!$insert){
	if($sgbd=='my'){
		echo mysql_error()."Erro: Falha ao inserir o registro!";
		exit;
	}elseif($sgbd=='pg'){
		echo pg_last_error()."Erro: Falha ao inserir o registro!";
	exit;
	}
}

	echo "<script>location='../grid.php?table=comissao_fundiaria';</script>";
	?>
	