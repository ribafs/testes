<?php
	session_start();
	if(!isset($_SESSION['access'])){
		print "Acesso direto negado!";
		exit;
	}
	include_once('../includes/connection.inc.php');
	include_once('../includes/functions.inc.php');

	$codigo_animal = $_POST[codigo_animal];
$codigo_irrigante_animal = $_POST[codigo_irrigante_animal];
$descricao_animal = $_POST[descricao_animal];
$quantidade_animal = $_POST[quantidade_animal];

$table = 'animais_servico';

$strInsert = "INSERT INTO $table (codigo_animal,codigo_irrigante_animal,descricao_animal,quantidade_animal) 
	VALUES ('$codigo_animal','$codigo_irrigante_animal','$descricao_animal','$quantidade_animal')";

	if($sgbd=='my'){
		$insert = mysql_query($strInsert);
	}elseif($sgbd=='pg'){
		$insert = pg_query($strInsert);
	}

	if (!$insert){
		if($sgbd=='my'){
			echo mysql_error()."Erro: Falha ao inserir o registro!";
			exit;
		}elseif($sgbd=='pg'){
			echo pg_last_error()."Erro: Falha ao inserir o registro!";
			exit;
		}
	}

	echo "<script>location='../grid.php?table=animais_servico';</script>";
	?>
	