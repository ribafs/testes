<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
	<?php 	
	//session_start();
	//if(!isset($_SESSION['access'])){
	//	print "Acesso direto negado!";
	//	exit;
	//}
	include_once('../includes/lang.php'); 
	if($lang=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif($lang=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/connection.inc.php');
	include_once('../includes/header2.php');
	include_once('../includes/functions.inc.php');
	include_once('../includes/includes.html');
	
	$strconsulta = pg_exec("SELECT MAX(codigo_animal) AS codigo FROM animais_servico");
	$cd_codigo=(pg_result($strconsulta,0,'codigo')+1);
	?>
	
	<script src="../includes/validate/jquery.validationEngine_br.js" type="text/javascript"></script>
	
	<br>
	<body onLoad="document.frmInsert.codigo_irrigante_animal.focus()">
	<h2 align=center><?php echo Adicionar.' '.ucfirst(Animal) . '  ' . ' de Serviço';?></h2>
	<br>
	<form method="POST" id="test" action="animais_servico_insdb.php" name="frmInsert">
	<table border="0" align="center">
	<tr><td>Código </td><td><input name="codigo_animal" type="text" id="codigo_animal" class="validate[required]" size="4" maxlength="4" <?php echo"value='$cd_codigo'";?> onFocus="status_msg.value='Ente campo é obrigatório'"  onBlur="status_msg.value=''" style="background-color:AliceBlue " READONLY></td></tr>
	<tr><td>Codigo Irrigante</td>
	<td><select name="codigo_irrigante_animal">
		<?php echo combo_codigo_irrigante_animal("codigo_irrigante", 0, "irrigante");?>
		</select>		
	</td></tr>	
	<tr><td>Descrição do Animal</td><td><input name="descricao_animal" type="text" size="20" maxlength="20" onFocus="status_msg.value='Campo descricao_animal'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Quantidade</td><td><input name="quantidade_animal" type="text" size="12" maxlength="12" onFocus="status_msg.value='Campo quantidade_animal'" onBlur="status_msg.value=''"></td></tr>
	<tr><td></td><td><input type="submit" class="submit" value="Inserir"></td></tr>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
		<tr><td colspan="2"><input type="text" id="status_msg" name="status_msg" value="quantidade_animal" size="60" readonly></td></tr>
	</table>

	</form>

	<?php 
	include_once("../includes/footer2.php"); 
	?>
	