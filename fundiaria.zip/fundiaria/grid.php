<?php 	
session_start();
if(!isset($_SESSION['access'])){
	print 'Direct Access denied!';
	exit;
}
$admin = $_SESSION['admin'];
include_once("./includes/lang.php"); 
if($lang=='br'){
	include_once('./includes/languages/brazilian.php');
}elseif($lang=='en'){
	include_once('./includes/languages/english.php');
}

print "<link rel=\"stylesheet\" href=\"./includes/style/style_green.css\" type=\"text/css\" media=\"screen\">";

$table = $_GET['table'];
include_once("./includes/header.php");
include_once("./includes/connection.inc.php");
include_once("./includes/functions.inc.php");

include_once("./includes/paging.php");
include_once("./includes/footer.php"); 

?>
