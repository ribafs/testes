<?php
	session_start();
	if(!isset($_SESSION['admin'])){
		print "Acesso direto negado!";
		exit;
	}
	include_once('../includes/connection.inc.php');
	include_once('../includes/functions.inc.php');
	$codigo_da_rebate = $_POST[codigo_da_rebate];
$nome_da_rebate = $_POST[nome_da_rebate];
$rg_da_rebate = $_POST[rg_da_rebate];
$cpf_da_rebate = $_POST[cpf_da_rebate];

$table = 'cadastro_da_rebate';

	// Support to multiple primary key
		$c=0;
		$count = count(primary_key($table));
		foreach(primary_key($table) as $p){
			if($c < $count-1){
				$pk .= $p . ',';
			}else{
				$pk .= $p;
			}
			$c ++;
		}

		$pk0 = explode(',',$pk);

	if($count ==1){
		$pk1=$pk0[0];
		$value1 = $_POST[$pk1];
		$value = "$pk1 = '$value1'";
	}elseif($count ==2){
		$pk1=$pk0[0];
		$pk2=$pk0[1];

		$value1 = $_POST[$pk1];
		$value2 = $_POST[$pk2];
		$value = "$pk1 = '$value1' AND $pk2 = '$value2'";
	}

	
$strUpdate="UPDATE $table SET codigo_da_rebate = '$codigo_da_rebate', nome_da_rebate = '$nome_da_rebate', rg_da_rebate = '$rg_da_rebate', cpf_da_rebate = '$cpf_da_rebate' WHERE $value ";

	if($sgbd=='my'){
		mysql_query($strUpdate) or die(mysql_error());
	}elseif($sgbd=='pg'){
		pg_query($strUpdate) or die(pg_last_error());
	}
	echo "<script>location='../grid.php?table=$table'</script>";
	?>
	