<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
<?php
error_reporting(0);
ini_set(“display_errors”, 0 );
?>	
	<?php
	session_start();
	//if(!isset($_SESSION['access'])){
	//	print "Acesso direto negado!";
	//	exit;
	//}
	if ($_SESSION['admin'] <> 's')
	{
		echo" <script>alert('Usuário não possui autorização para editar.');</script>";
		echo "<script>location='../menu.php';</script>";			
	}

	include_once('../includes/lang.php'); 
	if($lang=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif($lang=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/connection.inc.php');
	include_once('../includes/header2.php');
	include_once('../includes/functions.inc.php');
	include_once('../includes/includes.html');

		$table = 'cadastro_da_rebate';
		$c=0;
		$count = count(primary_key($table));
		foreach(primary_key($table) as $p){
			if($c < $count-1){
				$pk .= $p . ',';
			}else{
				$pk .= $p;
			}
			$c ++;
		}

		$pk0 = explode(',',$pk);

		if($count ==1){
			$pk1=$pk0[0];
			$value1 = $_GET[$pk1];
			$value = "$pk1 = '$value1'";
		}elseif($count ==2){
			$pk1=$pk0[0];
			$pk2=$pk0[1];

			$value1 = $_GET[$pk1];
			$value2 = $_GET[$pk2];
			$value = "$pk1 = '$value1' AND $pk2 = '$value2'";
		}

		$sql = "SELECT * FROM $table where $value";	
	

		if($sgbd == 'my'){
			$qry = mysql_query($sql);
			$reg = mysql_fetch_array($qry);
		}elseif($sgbd == 'pg'){
			$qry = pg_query($sql);
			$reg = pg_fetch_array($qry);
		}
	if($sgbd == 'my'){
		$nf=mysql_num_fields($qry);
		for($x=0;$x<$nf;$x++){
			$type = mysql_field_type($qry,$x);
			if($type == 'date'){
				$datefield = explode('-',$reg[$x]);
				$reg[$x] = $datefield[2].'/'.$datefield[1].'/'.$datefield[0];
				$dataget = $reg[$x];
			}
		}
	}elseif($sgbd == 'pg'){
		$nf=pg_num_fields($qry);
		for($x=0;$x<$nf;$x++){
			$type = pg_field_type($qry,$x);
			if($type == 'date'){
				$datefield = explode('-',$reg[$x]);
				$reg[$x] = $datefield[2].'/'.$datefield[1].'/'.$datefield[0];
				$dataget = $reg[$x];
			}
		}
	}
	?>
	
	<script src="../includes/validate/jquery.validationEngine_br.js" type="text/javascript"></script>
	
	<script>
		function mascara_cpf(cpf_da_rebate)
            {
                var mycpf = '';
                mycpf = mycpf + cpf_da_rebate;
                if (mycpf.length == 3) {
                mycpf = mycpf + '.';
                document.forms[0].cpf_da_rebate.value = mycpf;
                }
                if (mycpf.length == 7) {
                mycpf = mycpf + '.';
                document.forms[0].cpf_da_rebate.value = mycpf;
                }
                if (mycpf.length == 11) {
                mycpf = mycpf + '-';
                document.forms[0].cpf_da_rebate.value = mycpf;
                }
                if (mycpf.length == 14)
                {                     
                    valida_da_rebate_cpf();
                }
            }

            function valida_da_rebate_cpf()
            {                   
                
                var cpf=document.forms[0].cpf_da_rebate.value;                                                           
                campo1= cpf.substr(0,3);
                campo2= cpf.substr(4,3);
                campo3= cpf.substr(8,3);
                campo4= cpf.substr(12,2);
                    
                cpf=campo1+campo2+campo3+campo4;                     
                
                var numeros, digitos, soma, i, resultado, digitos_iguais;
                digitos_iguais = 1;
                if (cpf.length < 11)
                    return false;
                for (i = 0; i < cpf.length - 1; i++)                      
                    if (cpf.charAt(i) != cpf.charAt(i + 1))
                    {                        
                        digitos_iguais = 0;
                        break;
                    }                   
                      
                    if (!digitos_iguais)
                    { 
                        numeros = cpf.substring(0,9);
                        digitos = cpf.substring(9);
                        soma = 0;                      
                        for (i = 10; i > 1; i--)
                            soma += numeros.charAt(10 - i) * i;
                            resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
                            if (resultado != digitos.charAt(0))
                            {   
                                alert('CPF INVÁLIDO');
                                return false;
                            }
                            else
                            {    
                                numeros = cpf.substring(0,10);
                                soma = 0;
                            }
                        for (i = 11; i > 1; i--)
                            soma += numeros.charAt(11 - i) * i;
                            resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
                            if (resultado != digitos.charAt(1))
                            { 
                                alert('CPF INVÁLIDO');
                                return false;
                            }
                            else
                            {                            
                                 //alert('CPF VÁLIDO');
                                return true;
                            }
                    }
                    else
                       alert('CPF INVÁLIDO');
                        return false;
            }
	
	</script>
		<br><br><br>
	<body onLoad="document.frmUpdate.codigo_da_rebate.focus()">
	<h2 align=center><?php echo Editar.' '. DA. ' '.ucfirst(Rebate);?></h2>	

	<form name="frm_cadastro_da_rebate" method="post" action="cadastro_da_rebate_upddb.php" id="test">
	<br><br><br>
<table border="0" align="center">
		<input type="hidden" name="data2" value="<?php echo $dataget;?>">
		<table border="0" align="center">
		<tr><td>Codigo DA rebate</td><td><input name="codigo_da_rebate" type="text" size="6" maxlength="6" value="<?php echo trim($reg[0]);?>" readonly style="color:black" onFocus="status_msg.value='Este campo é obrigatório'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Nome do DA</td><td><input name="nome_da_rebate" type="text" size="50" maxlength="50" onFocus="status_msg.value='Campo nome_da_rebate'" onBlur="status_msg.value=''" value="<?php echo trim($reg[1]);?>"></td></tr>
	<tr><td>RG</td><td><input name="rg_da_rebate" type="text" size="40" maxlength="40" onFocus="status_msg.value='Campo rg_da_rebate'" onBlur="status_msg.value=''" value="<?php echo trim($reg[2]);?>"></td></tr>
	<tr><td>CPF</td><td><input name="cpf_da_rebate" type="text" size="14" maxlength="14"  onKeyUp="mascara_cpf(this.value)"  onFocus="status_msg.value='Campo cpf_da_rebate'" onBlur="status_msg.value=''" value="<?php echo trim($reg[3]);?>"></td></tr>
	<tr><td></td><td><input type="submit" class="submit" value="Atualizar"></td></tr>
		<tr><td colspan="2"><input type="text" id="status_msg" name="status_msg" value="cpf_da_rebate" size="60" readonly></td></tr>
	</table>
	</form>

	<?php 
	include_once("../includes/footer2.php"); 
	?>
	