<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
	<?php 	
	//session_start();
	//if(!isset($_SESSION['access'])){
	//	print "Acesso direto negado!";
	//	exit;
	//}
	include_once('../includes/lang.php'); 
	if($lang=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif($lang=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/connection.inc.php');
	include_once('../includes/header2.php');
	include_once('../includes/functions.inc.php');
	include_once('../includes/includes.html');
	
	$strconsulta = pg_exec("SELECT MAX(codigo_da_rebate) AS codigo FROM cadastro_da_rebate");
	$cd_codigo=(pg_result($strconsulta,0,'codigo')+1);
	
	?>
	
	<script src="../includes/validate/jquery.validationEngine_br.js" type="text/javascript"></script>
	<script>
		function mascara_cpf(cpf_da_rebate)
            {
                var mycpf = '';
                mycpf = mycpf + cpf_da_rebate;
                if (mycpf.length == 3) {
                mycpf = mycpf + '.';
                document.forms[0].cpf_da_rebate.value = mycpf;
                }
                if (mycpf.length == 7) {
                mycpf = mycpf + '.';
                document.forms[0].cpf_da_rebate.value = mycpf;
                }
                if (mycpf.length == 11) {
                mycpf = mycpf + '-';
                document.forms[0].cpf_da_rebate.value = mycpf;
                }
                if (mycpf.length == 14)
                {                     
                    valida_da_rebate_cpf();
                }
            }

            function valida_da_rebate_cpf()
            {                   
                
                var cpf=document.forms[0].cpf_da_rebate.value;                                                           
                campo1= cpf.substr(0,3);
                campo2= cpf.substr(4,3);
                campo3= cpf.substr(8,3);
                campo4= cpf.substr(12,2);
                    
                cpf=campo1+campo2+campo3+campo4;                     
                
                var numeros, digitos, soma, i, resultado, digitos_iguais;
                digitos_iguais = 1;
                if (cpf.length < 11)
                    return false;
                for (i = 0; i < cpf.length - 1; i++)                      
                    if (cpf.charAt(i) != cpf.charAt(i + 1))
                    {                        
                        digitos_iguais = 0;
                        break;
                    }                   
                      
                    if (!digitos_iguais)
                    { 
                        numeros = cpf.substring(0,9);
                        digitos = cpf.substring(9);
                        soma = 0;                      
                        for (i = 10; i > 1; i--)
                            soma += numeros.charAt(10 - i) * i;
                            resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
                            if (resultado != digitos.charAt(0))
                            {   
                                alert('CPF INVÁLIDO');
                                return false;
                            }
                            else
                            {    
                                numeros = cpf.substring(0,10);
                                soma = 0;
                            }
                        for (i = 11; i > 1; i--)
                            soma += numeros.charAt(11 - i) * i;
                            resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
                            if (resultado != digitos.charAt(1))
                            { 
                                alert('CPF INVÁLIDO');
                                return false;
                            }
                            else
                            {                            
                                 //alert('CPF VÁLIDO');
                                return true;
                            }
                    }
                    else
                       alert('CPF INVÁLIDO');
                        return false;
            }
	
	</script>
	
	
	<body onLoad="document.frmInsert.nome_da_rebate.focus()">
	<br><br><br>
	<h2 align=center><?php echo Adicionar.' '. DA. ' '.ucfirst(Rebate);?></h2>
<br><br>
	<form method="POST" id="test" action="cadastro_da_rebate_insdb.php" name="frmInsert">
	<table border="0" align="center">
	<tr><td>Codigo DA rebate</td><td><input name="codigo_da_rebate" type="text" id="codigo_da_rebate" class="validate[required]" size="3" maxlength="3" <?php echo"value='$cd_codigo'";?> onFocus="status_msg.value='Ente campo é obrigatório'"  onBlur="status_msg.value=''" style="background-color:AliceBlue " READONLY></td></tr>
	<tr><td>Nome do DA </td><td><input name="nome_da_rebate" type="text" size="50" maxlength="50" onFocus="status_msg.value='Campo nome_da_rebate'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>RG </td><td><input name="rg_da_rebate" type="text" size="50" maxlength="50" onFocus="status_msg.value='Campo rg_da_rebate'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>CPF </td><td><input name="cpf_da_rebate" type="text" size="14" maxlength="14" onKeyUp="mascara_cpf(this.value)" onFocus="status_msg.value='Campo cpf_da_rebate'" onBlur="status_msg.value=''"></td></tr>
	<tr><td></td><td><input type="submit" class="submit" value="Inserir"></td></tr>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
		<tr><td colspan="2"><input type="text" id="status_msg" name="status_msg" value="cpf_da_rebate" size="60" readonly></td></tr>
	</table>

	</form>

	<?php 
	include_once("../includes/footer2.php"); 
	?>
	