<?php
	session_start();
	if(!isset($_SESSION['access'])){
		print "Acesso direto negado!";
		exit;
	}
	include_once('../includes/connection.inc.php');
	include_once('../includes/functions.inc.php');

	$codigo_da_rebate = $_POST[codigo_da_rebate];
$nome_da_rebate = $_POST[nome_da_rebate];
$rg_da_rebate = $_POST[rg_da_rebate];
$cpf_da_rebate = $_POST[cpf_da_rebate];

$table = 'cadastro_da_rebate';

$strInsert = "INSERT INTO $table (codigo_da_rebate,nome_da_rebate,rg_da_rebate,cpf_da_rebate) 
	VALUES ('$codigo_da_rebate','$nome_da_rebate','$rg_da_rebate','$cpf_da_rebate')";

	if($sgbd=='my'){
		$insert = mysql_query($strInsert);
	}elseif($sgbd=='pg'){
		$insert = pg_query($strInsert);
	}

	if (!$insert){
		if($sgbd=='my'){
			echo mysql_error()."Erro: Falha ao inserir o registro!";
			exit;
		}elseif($sgbd=='pg'){
			echo pg_last_error()."Erro: Falha ao inserir o registro!";
			exit;
		}
	}

	echo "<script>location='../grid.php?table=cadastro_da_rebate';</script>";
	?>
	