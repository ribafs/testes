<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
	<?php 	
	//session_start();
	//if(!isset($_SESSION['access'])){
	//	print "Acesso direto negado!";
	//	exit;
	//}
	include_once('../includes/lang.php'); 
	if($lang=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif($lang=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/connection.inc.php');
	include_once('../includes/header2.php');
	include_once('../includes/functions.inc.php');
	include_once('../includes/includes.html');
	
	$strconsulta = pg_exec("SELECT MAX(codigo_ferramenta) AS codigo FROM ferramenta");
	$cd_codigo=(pg_result($strconsulta,0,'codigo')+1);
	?>
	<br>
	<script src="../includes/validate/jquery.validationEngine_br.js" type="text/javascript"></script>
	<body onLoad="document.frmInsert.codigo_irrigante_ferramenta.focus()">
	<h2 align=center><?php echo Adicionar.' '.ucfirst(ferramenta);?></h2>
	<br>
	<form method="POST" id="test" action="ferramenta_insdb.php" name="frmInsert">
	<table border="0" align="center">
	<tr><td>Código</td><td><input name="codigo_ferramenta" type="text" id="codigo_ferramenta" class="validate[required]" size="4" maxlength="4" <?php echo"value='$cd_codigo'";?> onFocus="status_msg.value='Ente campo é obrigatório'"  onBlur="status_msg.value=''" style="background-color:AliceBlue " READONLY></td></tr>		
	<tr><td>Código Irrigante &nbsp &nbsp </td><td>
	<select name="codigo_irrigante_ferramenta">
		<?php echo combo_codigo_irrigante_ferramenta("codigo_irrigante", 0, "irrigante");?>
		</select>		
	</td></tr>		
	<tr><td>Descrição Ferramenta</td><td><input name="descricao_ferramenta" type="text" size="25" maxlength="25" onFocus="status_msg.value='Campo descricao_ferramenta'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Quantidade </td><td><input name="quantidade_ferramenta" type="text" size="12" maxlength="12" onFocus="status_msg.value='Campo quantidade_ferramenta'" onBlur="status_msg.value=''"></td></tr>
	<tr><td></td><td><input type="submit" class="submit" value="Inserir"></td></tr>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
		<tr><td colspan="2"><input type="text" id="status_msg" name="status_msg" value="quantidade_ferramenta" size="60" readonly></td></tr>
	</table>

	</form>

	<?php 
	include_once("../includes/footer2.php"); 
	?>
	