<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
<?php
error_reporting(0);
ini_set(“display_errors”, 0 );
?>	
	<?php
	session_start();
	//if(!isset($_SESSION['access'])){
	//	print "Acesso direto negado!";
	//	exit;
	//}
	if ($_SESSION['admin'] <> 's')
	{
		echo" <script>alert('Usuário não possui autorização para editar.');</script>";
		echo "<script>location='../menu.php';</script>";			
	}

	include_once('../includes/lang.php'); 
	if($lang=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif($lang=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/connection.inc.php');
	include_once('../includes/header2.php');
	include_once('../includes/functions.inc.php');
	include_once('../includes/includes.html');

		$table = 'ferramenta';
		$c=0;
		$count = count(primary_key($table));
		foreach(primary_key($table) as $p){
			if($c < $count-1){
				$pk .= $p . ',';
			}else{
				$pk .= $p;
			}
			$c ++;
		}

		$pk0 = explode(',',$pk);

		if($count ==1){
			$pk1=$pk0[0];
			$value1 = $_GET[$pk1];
			$value = "$pk1 = '$value1'";
		}elseif($count ==2){
			$pk1=$pk0[0];
			$pk2=$pk0[1];

			$value1 = $_GET[$pk1];
			$value2 = $_GET[$pk2];
			$value = "$pk1 = '$value1' AND $pk2 = '$value2'";
		}

		$sql = "SELECT * FROM $table where $value";	
	

		if($sgbd == 'my'){
			$qry = mysql_query($sql);
			$reg = mysql_fetch_array($qry);
		}elseif($sgbd == 'pg'){
			$qry = pg_query($sql);
			$reg = pg_fetch_array($qry);
		}
	if($sgbd == 'my'){
		$nf=mysql_num_fields($qry);
		for($x=0;$x<$nf;$x++){
			$type = mysql_field_type($qry,$x);
			if($type == 'date'){
				$datefield = explode('-',$reg[$x]);
				$reg[$x] = $datefield[2].'/'.$datefield[1].'/'.$datefield[0];
				$dataget = $reg[$x];
			}
		}
	}elseif($sgbd == 'pg'){
		$nf=pg_num_fields($qry);
		for($x=0;$x<$nf;$x++){
			$type = pg_field_type($qry,$x);
			if($type == 'date'){
				$datefield = explode('-',$reg[$x]);
				$reg[$x] = $datefield[2].'/'.$datefield[1].'/'.$datefield[0];
				$dataget = $reg[$x];
			}
		}
	}
	?>
	
	<script src="../includes/validate/jquery.validationEngine_br.js" type="text/javascript"></script>
	<br>
	<body onLoad="document.frmUpdate.codigo_ferramenta.focus()">
	<h2 align=center><?php echo 'Editar ' .ucfirst(ferramenta);?></h2>
	<br>
	<form name="frm_ferramenta" method="post" action="ferramenta_upddb.php" id="test">
	<table border="0" align="center">
		<input type="hidden" name="data2" value="<?php echo $dataget;?>">
		<table border="0" align="center">
		<tr><td>Codigo_ferramenta</td><td><input name="codigo_ferramenta" type="text" size="" maxlength="" value="<?php echo trim($reg[0]);?>" readonly style="color:black" onFocus="status_msg.value='Este campo é obrigatório'" onBlur="status_msg.value=''" READONLY></td></tr>	
	<tr><td>Código Irrigante &nbsp &nbsp </td><td>
	<select name="codigo_irrigante_ferramenta">
		<?php echo combo_codigo_irrigante_ferramenta("codigo_irrigante", $reg[1], "irrigante");?>
		</select>		
	</td></tr>			
	<tr><td>Descricao ferramenta</td><td><input name="descricao_ferramenta" type="text" size="" maxlength="" onFocus="status_msg.value='Campo descricao_ferramenta'" onBlur="status_msg.value=''" value="<?php echo trim($reg[2]);?>"></td></tr>
	<tr><td>Quantidade</td><td><input name="quantidade_ferramenta" type="text" size="" maxlength="" onFocus="status_msg.value='Campo quantidade_ferramenta'" onBlur="status_msg.value=''" value="<?php echo trim($reg[3]);?>"></td></tr>
	<tr><td></td><td><input type="submit" class="submit" value="Atualizar"></td></tr>
		<tr><td colspan="2"><input type="text" id="status_msg" name="status_msg" value="quantidade_ferramenta" size="60" readonly></td></tr>
	</table>
	</form>

	<?php 
	include_once("../includes/footer2.php"); 
	?>
	