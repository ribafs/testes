<?php
	session_start();
	if(!isset($_SESSION['access'])){
		print "Acesso direto negado!";
		exit;
	}
	include_once('../includes/connection.inc.php');
	include_once('../includes/functions.inc.php');

	$codigo_ferramenta = $_POST[codigo_ferramenta];
$codigo_irrigante_ferramenta = $_POST[codigo_irrigante_ferramenta];
$descricao_ferramenta = $_POST[descricao_ferramenta];
$quantidade_ferramenta = $_POST[quantidade_ferramenta];

$table = 'ferramenta';

$strInsert = "INSERT INTO $table (codigo_ferramenta,codigo_irrigante_ferramenta,descricao_ferramenta,quantidade_ferramenta) 
	VALUES ('$codigo_ferramenta','$codigo_irrigante_ferramenta','$descricao_ferramenta','$quantidade_ferramenta')";

	if($sgbd=='my'){
		$insert = mysql_query($strInsert);
	}elseif($sgbd=='pg'){
		$insert = pg_query($strInsert);
	}

	if (!$insert){
		if($sgbd=='my'){
			echo mysql_error()."Erro: Falha ao inserir o registro!";
			exit;
		}elseif($sgbd=='pg'){
			echo pg_last_error()."Erro: Falha ao inserir o registro!";
			exit;
		}
	}

	echo "<script>location='../grid.php?table=ferramenta';</script>";
	?>
	