<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
	<?php 	
	//session_start();
	//if(!isset($_SESSION['access'])){
	//	print "Acesso direto negado!";
	//	exit;
	//}
	include_once('../includes/lang.php'); 
	if($lang=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif($lang=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/connection.inc.php');
	include_once('../includes/header2.php');
	include_once('../includes/functions.inc.php');
	include_once('../includes/includes.html');
	?>
	
	<script src="../includes/validate/jquery.validationEngine_br.js" type="text/javascript"></script>
	<body onLoad="document.frmInsert.login.focus()">
	<h2 align=center><?php echo Adicionar.' '.ucfirst(acesso);?></h2>

	<form method="POST" id="test" action="acesso_insdb.php" name="frmInsert">
	<table border="0" align="center">
	<tr><td>Login</td><td><input name="login" type="text" id="login" class="validate[required]" size="12" maxlength="12" onFocus="status_msg.value='Este campo é obrigatório'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Password</td><td><input name="password" type="text" size="32" maxlength="32" onFocus="status_msg.value='Campo password'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Admin</td><td><input name="admin" type="text" size="1" maxlength="1" onFocus="status_msg.value='Campo admin'" onBlur="status_msg.value=''"></td></tr>
	<tr><td></td><td><input type="submit" class="submit" value="Inserir"></td></tr>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
		<tr><td colspan="2"><input type="text" id="status_msg" name="status_msg" value="admin" size="60" readonly></td></tr>
	</table>

	</form>

	<?php 
	include_once("../includes/footer2.php"); 
	?>
	