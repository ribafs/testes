<?php
	session_start();
	if(!isset($_SESSION['access'])){
		print "Acesso direto negado!";
		exit;
	}
	include_once('../includes/connection.inc.php');
	include_once('../includes/functions.inc.php');

	$login = $_POST[login];
$password = md5($_POST[password]);
$admin = $_POST[admin];

$table = 'acesso';

$strInsert = "INSERT INTO $table (login,password,admin) 
	VALUES ('$login','$password','$admin')";

	if($sgbd=='my'){
		$insert = mysql_query($strInsert);
	}elseif($sgbd=='pg'){
		$insert = pg_query($strInsert);
	}

	if (!$insert){
		if($sgbd=='my'){
			echo mysql_error()."Erro: Falha ao inserir o registro!";
			exit;
		}elseif($sgbd=='pg'){
			echo pg_last_error()."Erro: Falha ao inserir o registro!";
			exit;
		}
	}

	echo "<script>location='../grid.php?table=acesso';</script>";
	?>
	