<?php header("Content-Type: text/html;  charset=UTF-8",true) ?>
	<?php
	session_start();
	if(!isset($_SESSION['access'])){
		print "Acesso direto negado!";
		exit;
	}

	include_once('../includes/lang.php'); 
	if($lang=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif($lang=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/connection.inc.php');
	include_once('../includes/header2.php');
	include_once('../includes/functions.inc.php');
	include_once('../includes/includes.html');

		$table = 'acesso';
		$c=0;
		$count = count(primary_key($table));
		foreach(primary_key($table) as $p){
			if($c < $count-1){
				$pk .= $p . ',';
			}else{
				$pk .= $p;
			}
			$c ++;
		}

		$pk0 = explode(',',$pk);

		if($count ==1){
			$pk1=$pk0[0];
			$value1 = $_GET[$pk1];
			$value = "$pk1 = '$value1'";
		}elseif($count ==2){
			$pk1=$pk0[0];
			$pk2=$pk0[1];

			$value1 = $_GET[$pk1];
			$value2 = $_GET[$pk2];
			$value = "$pk1 = '$value1' AND $pk2 = '$value2'";
		}

		$sql = "SELECT * FROM $table where $value";	
	

		if($sgbd == 'my'){
			$qry = mysql_query($sql);
			$reg = mysql_fetch_array($qry);
		}elseif($sgbd == 'pg'){
			$qry = pg_query($sql);
			$reg = pg_fetch_array($qry);
		}
	if($sgbd == 'my'){
		$nf=mysql_num_fields($qry);
		for($x=0;$x<$nf;$x++){
			$type = mysql_field_type($qry,$x);
			if($type == 'date'){
				$datefield = explode('-',$reg[$x]);
				$reg[$x] = $datefield[2].'/'.$datefield[1].'/'.$datefield[0];
				$dataget = $reg[$x];
			}
		}
	}elseif($sgbd == 'pg'){
		$nf=pg_num_fields($qry);
		for($x=0;$x<$nf;$x++){
			$type = pg_field_type($qry,$x);
			if($type == 'date'){
				$datefield = explode('-',$reg[$x]);
				$reg[$x] = $datefield[2].'/'.$datefield[1].'/'.$datefield[0];
				$dataget = $reg[$x];
			}
		}
	}
	?>
	
	<script src="../includes/validate/jquery.validationEngine_br.js" type="text/javascript"></script>
	
	<body onLoad="document.frmUpdate.login.focus()">
	<h2 align=center><?php echo 'Editar ' .ucfirst(acesso);?></h2>

	<form name="frm_acesso" method="post" action="acesso_upddb.php" id="test">
<table border="0" align="center">
		<input type="hidden" name="data2" value="<?php echo $dataget;?>">
		<table border="0" align="center">
		<tr><td>Login</td><td><input name="login" type="text" size="" maxlength="" value="<?php echo trim($reg[0]);?>" readonly style="color:black" onFocus="status_msg.value='Este campo é obrigatório'" onBlur="status_msg.value=''"></td></tr>
	<tr><td>Password</td><td><input name="password" type="text" size="" maxlength="" onFocus="status_msg.value='Campo password'" onBlur="status_msg.value=''" value="<?php echo trim($reg[1]);?>"></td></tr>
	<tr><td>Admin</td><td><input name="admin" type="text" size="" maxlength="" onFocus="status_msg.value='Campo admin'" onBlur="status_msg.value=''" value="<?php echo trim($reg[2]);?>"></td></tr>
	<tr><td></td><td><input type="submit" class="submit" value="Atualizar"></td></tr>
		<tr><td colspan="2"><input type="text" id="status_msg" name="status_msg" value="admin" size="60" readonly></td></tr>
	</table>
	</form>

	<?php 
	include_once("../includes/footer2.php"); 
	?>
	