<div class="container bg-gray">
    <div align="center">
        <a href="<?=URL . 'product/index'?>" class="text-center">Back to menu</a><br>
        <a href="https://github.com/ribafs/mini-framework-ribafs">Mini Framework RibaFS on GitHub</a>.<br>
    </div>
</div>
</body>
</html>

