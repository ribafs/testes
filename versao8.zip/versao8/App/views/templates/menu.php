		<!-- MENU -->
		<nav class="navbar-expand bg-secondary navbar-dark mt-0">
			<ul class="navbar-nav justify-content-center">
			  <h4><li class="nav-item"><a class="nav-link link-warning pe-2" href="<?php echo URL; ?>product">Products</a></li></h4>
			</ul>
		</nav>
	</div>
